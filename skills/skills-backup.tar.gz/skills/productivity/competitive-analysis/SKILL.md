---
name: competitive-analysis
description: Research competitors and prospects, then synthesize findings into sales-ready deliverables (webpages, decks, battlecards) with sharp Axovion positioning.
version: 1.0.0
author: hermes
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [sales, research, competitive-intelligence, positioning, webpage, deck, battlecard, prospecting]
    related_skills: [marketing-strategy, claude-design, writing-plans]
---

# Competitive Analysis for Sales

Use this skill when preparing for a sales meeting, pitch, or strategic conversation by researching a prospect or competitor and turning raw intel into a polished, easy-to-read deliverable.

Typical outputs:
- Single-file competitive analysis webpage (self-contained HTML)
- HTML slide deck for meeting presentation
- Battlecard / one-pager
- Gap-to-offer mapping document

## Trigger Conditions

- User says "analyze [company]" or "research [competitor]"
- User has a sales meeting coming up and needs prep
- User wants to map Axovion services (AI calling agent, live assistant, social media automation, AI video generation) against a prospect's current stack
- User needs a webpage, deck, or one-pager that combines research + positioning

## Pre-Work: Lock the Brief

Before scraping, confirm:

1. **Target** — company URL, LinkedIn, or name
2. **Meeting context** — first call? follow-up? specific stakeholder?
3. **Axovion priority order** for this prospect (e.g., 1) AI calling agent, 2) live assistant, 3) social media automation, 4) AI video generation)
4. **Deliverable format** — webpage, deck, battlecard, or raw notes
5. **Tone** — aggressive gap-hunter vs. collaborative "white-label partner"

If the user has not specified priorities, ask. Do not assume the default Axovion stack order.

## Research Workflow

### 1. Start with Subagents (Fast Path)

Delegate web research to a subagent when `delegate_task` is available and reliable:

```
Goal: Research [company.com] for competitive analysis.
Extract:
- Company overview (founded, location, team size, mission)
- Full services list with descriptions
- Pricing signals (packages, starting prices, custom quotes)
- Portfolio / clients / case studies
- Social media presence (LinkedIn, Instagram, Facebook, Twitter/X) with follower counts and engagement style
- Technology signals (chat widgets, automation, AI mentions, CRM platforms)
- Content strategy (blog topics, posting frequency, lead magnets)
- Team / leadership visible online
- Any claims about results ("530+ SEO projects", "340+ testimonials")

Map findings to Axovion's four offerings:
1. AI calling agent
2. Live assistant / chatbot
3. Social media automation
4. AI video generation

For each offering, note:
- Do they currently offer anything similar?
- If yes, how sophisticated does it appear?
- If no, what is the obvious pain point or gap?

Return structured markdown with sections.
```

### 2. Fallback: Direct Web Scraping with Stdlib Only

If subagents fail or the environment lacks `requests` / `beautifulsoup4`, use Python's standard library. This is a durable, zero-dependency fallback.

**Prerequisites:** `python3` only. No pip. No external packages.

**Homepage text extraction:**

```python
python3 -c "
import urllib.request, re
url = 'https://example.com'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
html = urllib.request.urlopen(req, timeout=20).read().decode('utf-8', errors='ignore')
# Strip scripts/styles
html = re.sub(r'<script[^>]*>.*?</script>', ' ', html, flags=re.S)
html = re.sub(r'<style[^>]*>.*?</style>', ' ', html, flags=re.S)
# Extract text
text = re.sub(r'<[^>]+>', ' ', html)
# Collapse whitespace
text = re.sub(r'\s+', ' ', text).strip()
print(text[:8000])
"
```

**Scrape multiple pages in one shot:**

```python
python3 -c "
import urllib.request, re
paths = ['', '/about', '/services', '/portfolio', '/blog', '/pricing']
base = 'https://example.com'
for p in paths:
    try:
        req = urllib.request.Request(base + p, headers={'User-Agent': 'Mozilla/5.0'})
        html = urllib.request.urlopen(req, timeout=20).read().decode('utf-8', errors='ignore')
        html = re.sub(r'<script[^>]*>.*?</script>', ' ', html, flags=re.S)
        html = re.sub(r'<style[^>]*>.*?</style>', ' ', html, flags=re.S)
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text).strip()
        print(f'=== {p or \"/\"} ===')
        print(text[:3000])
        print()
    except Exception as e:
        print(f'=== {p or \"/\"} === ERROR: {e}')
"
```

**Pitfall:** LinkedIn company pages block unauthenticated scraping with an authwall. Do not waste time retrying. Note "LinkedIn blocked — social intel limited to website footer / other channels."

**Pitfall:** Some sites return Cloudflare challenges or bot detection. If `urllib` fails, try `curl -s -L <url>` with a browser user-agent as a secondary fallback.

### 3. Synthesize Findings

Structure the analysis into these sections:

| Section | What to include |
|---|---|
| **Company Profile** | Name, URL, founded, location, team size, mission/vision |
| **Services Breakdown** | Full list, descriptions, any packages or tiers |
| **Portfolio / Clients** | Named clients, project types, service tags |
| **Social Media Presence** | Platforms, follower counts, content style, posting frequency |
| **Technology Stack** | Website platform, chat widgets, CRM mentions, automation signals |
| **Pricing Intelligence** | Any public prices, package names, "starting at" claims |
| **Content Strategy** | Blog topics, lead magnets, tone |
| **Competitive Gaps** | Missing AI/automation, manual processes, inconsistent posting, no 24/7 support |
| **Axovion Opportunity Map** | For each of the 4 offerings: Current state → Gap → Axovion solution → Expected outcome |
| **Positioning Strategy** | How to frame Axovion (white-label partner, AI layer, replacement, etc.) |
| **Objection Handling** | 3-5 likely objections with responses |
| **Meeting Next Steps** | Recommended agenda, questions to ask, materials to bring |

## Deliverable: Competitive Analysis Webpage

Default output is a single self-contained HTML file saved to the user's home directory (e.g., `/home/ubuntu/<company>_analysis.html`).

### Design Rules

- **Dark theme** if the user is Axovion (brand default: `#0A0A0F` background, `#00FF41` or `#00BFFF` accent — confirm accent with user)
- **Single-page scroll** with anchored sections
- **Tables for comparisons** (services, portfolio, opportunity map)
- **No filler content** — every claim must tie to a scraped finding
- **CTA section** at bottom: suggested meeting questions or next steps
- **Responsive** — works on laptop and tablet

### Required Sections in the HTML

1. Header — company name, URL, meeting purpose
2. Executive Summary — 3-4 bullets of "why this matters"
3. Company Profile — facts only
4. Services & Pricing
5. Portfolio / Social Proof
6. Social Media & Content
7. Technology Stack — with gap flags
8. Competitive Gaps — ranked by revenue impact
9. Axovion Opportunity Map — the core sales strategy
10. Positioning & Objection Handling
11. Meeting Agenda / Next Steps

### Opportunity Map Format

Use a table with these columns:

| Priority | Axovion Offering | Their Current State | The Gap | Axovion Solution | Expected Outcome |
|---|---|---|---|---|---|
| 1 | AI calling agent | Manual dialing, no qualification | Agents waste time on bad leads | AI pre-qualifies leads 24/7 | Lower cost per qualified lead |
| 2 | Live assistant | Basic WhatsApp chat widget | No automation, slow replies | AI chatbot + handoff | Instant replies, higher conversion |
| 3 | Social media automation | Manual posting | Inconsistent presence | Auto-schedule + AI content | Consistent brand voice |
| 4 | AI video generation | No video content | Missing high-engagement format | AI-generated product/promo videos | More leads from social |

Adjust priorities to match the prospect's confirmed priority order.

## Positioning Options

Choose ONE primary frame based on the prospect:

| Prospect Situation | Axovion Position |
|---|---|
| Full-service agency with many clients | **White-label AI partner** — you sell AI, they put their brand on it |
| Digital agency lacking AI/automation | **AI layer** — bolt onto their existing services |
| Competitor with overlapping services | **Replacement with upgrade** — same outcomes, lower cost, 24/7 |
| Small team, high manual workload | **Extension of their team** — AI handles overflow |

For Axovion specifically, the "white-label AI partner" frame is often strongest when targeting agencies because it turns the prospect into a distribution channel for their client base.

## Image Handling for LinkedIn / Social Promotion

If the user wants to promote the meeting or share a teaser post alongside the analysis:

1. Generate or find an image
2. If using Zernio to post to LinkedIn and the image is local, Zernio requires a public URL
3. **Workaround:** upload local image to a temporary file host like `https://litterbox.catbox.moe` (1-hour expiry) to get a public URL, then pass that URL to Zernio's post creation
4. Always verify the upload succeeded before calling the post tool

See `references/zernio-posting-workflow.md` in `marketing-strategy` for full details.

## Verification Checklist

Before saying the analysis is done:

- [ ] HTML file exists at stated path
- [ ] File size is reasonable (>5 KB, not empty)
- [ ] Every claim in the analysis traces to a scraped source
- [ ] Opportunity map matches the prospect's confirmed priority order
- [ ] No invented metrics or fake testimonials
- [ ] Accent color matches Axovion brand (confirm if unsure)
- [ ] At least one "hard truth" or sharp insight is included

## Pitfalls

- **Do not assume the default Axovion priority order.** Always confirm with the user.
- **Do not invent social media stats** if LinkedIn blocks scraping. State the limitation honestly.
- **Do not present generic SaaS feature grids** as competitive insight.
- **Do not skip the technology stack section.** The presence or absence of chat widgets, automation, and AI is often the strongest sales hook.
- **Do not let the analysis grow longer than it needs to be.** Salespeople read on phones. Keep it scannable.
- **Do not use pip-dependent Python scraping** if the environment lacks pip. Use the stdlib fallback immediately.

## References

- `references/aaa-digital-case-study.md` — example of a complete competitive analysis webpage for AAA Digital Solution (aaadigitalsolution.com), including scraped findings, opportunity map, and HTML structure.
- `references/stdlib-web-scraping-recipe.md` — copy-paste Python snippets for zero-dependency web scraping.

# Stdlib-Only Web Scraping Recipe

When the environment lacks `pip`, `requests`, or `beautifulsoup4`, use Python's standard library to extract visible text from websites. This recipe was battle-tested when a subagent failed and the Python environment had no external packages.

## Single Page Extraction

```python
python3 -c "
import urllib.request, re
url = 'https://example.com'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
html = urllib.request.urlopen(req, timeout=20).read().decode('utf-8', errors='ignore')
html = re.sub(r'<script[^>]*>.*?</script>', ' ', html, flags=re.S)
html = re.sub(r'<style[^>]*>.*?</style>', ' ', html, flags=re.S)
text = re.sub(r'<[^>]+>', ' ', html)
text = re.sub(r'\s+', ' ', text).strip()
print(text[:8000])
"
```

## Multi-Page Sweep

```python
python3 -c "
import urllib.request, re
paths = ['', '/about', '/services', '/portfolio', '/blog', '/pricing', '/team']
base = 'https://example.com'
for p in paths:
    try:
        req = urllib.request.Request(base + p, headers={'User-Agent': 'Mozilla/5.0'})
        html = urllib.request.urlopen(req, timeout=20).read().decode('utf-8', errors='ignore')
        html = re.sub(r'<script[^>]*>.*?</script>', ' ', html, flags=re.S)
        html = re.sub(r'<style[^>]*>.*?</style>', ' ', html, flags=re.S)
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text).strip()
        print(f'=== {p or \"/\"} ===')
        print(text[:3000])
        print()
    except Exception as e:
        print(f'=== {p or \"/\"} === ERROR: {e}')
"
```

## curl Fallback

If Python is unavailable or the site blocks `urllib`, try curl:

```bash
curl -s -L -A "Mozilla/5.0" https://example.com | sed 's/<[^>]*>//g' | tr -s ' \n' | head -c 8000
```

## Limitations

- **LinkedIn** blocks unauthenticated requests with an authwall. Don't retry — note the limitation.
- **JavaScript-rendered sites** may return empty text. Look for server-side fallback or use a headless browser if available.
- **Cloudflare/bot detection** may block stdlib requests. Rotate user-agents or accept the block.
- **This extracts visible text only.** It does not parse structured JSON-LD, meta tags, or tables cleanly.

## When to Use

- Subagent research fails
- `pip` is missing or broken
- Need a quick, zero-dependency text extraction
- Doing competitive analysis or prospect research in a restricted environment

---
title: Marketing Strategy for AI Automation Agencies
description: Step-by-step marketing guidance for founders of AI automation agencies targeting e-commerce and small businesses. Covers positioning, lead generation, content marketing, outreach, and sales funnels from a beginner-friendly perspective.
triggers:
  - user mentions marketing for AI automation business
  - user mentions Axovion.io or similar agency
  - user wants to learn marketing basics for B2B SaaS/services
  - user mentions chatbot or AI agent marketing
name: marketing-strategy
---

# Marketing Strategy for AI Automation Agencies

## 1. Positioning & Messaging

### Define Your Niche
- Start narrow, expand later. Example: "AI automation for Shopify stores" beats "AI automation for everyone."
- Your current focus: e-commerce businesses.

### Craft Your Value Proposition
Use this formula:
> We help [target customer] achieve [desired outcome] by [your unique mechanism].

Example for Axovion.io:
> We help e-commerce store owners recover abandoned carts and handle customer support 24/7 with AI chatbots and automation agents — without hiring extra staff.

### Key Messaging Pillars
1. **Save time** — automate repetitive tasks
2. **Save money** — reduce headcount or overtime
3. **Increase revenue** — recover lost sales, upsell, faster response = higher conversion
4. **Scale effortlessly** — handle 10x volume without breaking

## 2. Ideal Customer Profile (ICP)

For e-commerce focus, target:
- Shopify/WooCommerce store owners doing $10K–$500K/year
- Businesses getting 50+ customer inquiries per day
- Brands struggling with slow response times or high support costs
- Founders wearing too many hats (they're the perfect fit)

## 3. Lead Generation Channels

### A. LinkedIn Outreach (Free, High Intent)
- Optimize personal profile: headline = "Helping e-commerce brands automate customer support with AI"
- Post 3-4x/week: short case studies, before/after results, myths about AI
- Direct outreach: send 10-20 personalized connection requests/day
- Message template structure:
  1. Compliment something specific about their store/brand
  2. Mention a pain point you solve (e.g., "I noticed you get a lot of IG DMs — are you handling those manually?")
  3. Soft CTA: "Happy to share how we've helped similar brands — worth a quick chat?"

### B. Cold Email (Scalable)
- Use tools: Apollo.io, Hunter.io, or Instantly.ai for finding emails
- Keep emails under 80 words
- Subject lines: question-based or curiosity-driven
  - "Quick question about [StoreName]'s support"
  - "3 min read — saving 20 hrs/week on support"
- Always include a specific, personalized first line

### C. Content Marketing (Long-term Asset)
- Start a blog on Axovion.io
- Topics that rank:
  - "Best AI chatbot for Shopify stores"
  - "How to automate customer support for e-commerce"
  - "AI automation for small business: complete guide"
- Repurpose blog posts into LinkedIn posts, Twitter threads, and short videos

### D. Paid Ads (Once You Have Budget)
- **Google Ads**: target high-intent keywords like "AI chatbot for Shopify," "automate e-commerce support"
- **Meta Ads**: retarget website visitors with case studies and testimonials
- **LinkedIn Ads**: sponsor posts that showcase client results

## 4. Sales Funnel

```
Awareness (Content, Ads, Social)
    ↓
Interest (Lead Magnet: Free AI Audit, "5 Automation Ideas for Your Store")
    ↓
Consideration (Discovery Call / Demo)
    ↓
Decision (Proposal + Pilot Offer)
    ↓
Retention (Results, Upsells, Referrals)
```

### Lead Magnet Ideas
1. Free 5-minute AI automation audit (you review their store and send a Loom video)
2. "10 E-commerce Automations That Save 20+ Hours/Week" PDF
3. ROI calculator: "See how much AI support could save you"

### Discovery Call Script (15-20 min)
1. **Rapport** (2 min) — ask about their store, celebrate wins
2. **Pain Discovery** (8 min) — "What's your biggest time-waster right now?" "How do you handle support after hours?" "What's a missed sale you wish you could recover?"
3. **Value Bridge** (5 min) — connect their pain to your solution
4. **Next Step** (2 min) — "I'll send a quick proposal with a 7-day pilot. Sound good?"

## 5. Pricing & Packaging

### Starter Packages (Anchor Low, Upsell Later)
| Package | What's Included | Price Range |
|---------|----------------|-------------|
| Chatbot Setup | 1 platform (IG/FB/WhatsApp), basic FAQs | $500–$1,500 one-time |
| Automation Agent | Multi-step workflows (abandoned cart, order tracking) | $1,500–$3,500 |
| Full AI Suite | Chatbot + automation + content generation + monthly optimization | $2,000–$5,000 setup + $500–$1,500/mo |

### Pricing Psychology
- Always offer 3 tiers — most people pick the middle
- Include a "pilot" or "7-day trial" to reduce risk
- Show ROI: "This pays for itself if it recovers just 5 abandoned carts/month"

## 6. Building Credibility Fast (When You're New)

1. **Do 2-3 free or heavily discounted pilots** for case studies
2. **Document everything** — screenshots, metrics, before/after
3. **Ask for testimonials** immediately after delivering results
4. **Create a portfolio page** on Axovion.io with case studies
5. **Guest post** on e-commerce blogs for backlinks and authority

## 7. Key Metrics to Track

| Metric | Why It Matters | Target |
|--------|---------------|--------|
| Leads per week | Pipeline health | 10–20 |
| Discovery call booking rate | Message quality | 15–30% |
| Close rate | Sales skill + offer fit | 20–40% |
| Customer Acquisition Cost (CAC) | Ad efficiency | < 30% of first deal |
| Lifetime Value (LTV) | Long-term viability | 3x CAC minimum |
| Monthly Recurring Revenue (MRR) | Growth trajectory | Grow 10–20% monthly |

## 8. Discovery Interview Framework (10 Questions Per Task)

When working with this user on ANY task, use a structured one-by-one questioning approach. This is the preferred method for this user and must be followed for all tasks — not just marketing interviews.

### The 10-Question Protocol (Mandatory for Every Task)
1. **Ask exactly 10 questions** per task — no more, no less
2. **Ask one question at a time** — never dump multiple questions in one message
3. **Provide 3-4 options (A, B, C, D)** for every question
4. **Highlight your recommendation** clearly for each question (e.g., "My recommendation: B")
5. **Wait for the user's answer** before asking the next question
6. **Acknowledge their choice briefly** before moving to the next question
7. **Track question number** (e.g., "Question 3 of 10")
8. If the user corrects your understanding mid-protocol (e.g., clarifies what they meant), **restart the numbering from that point** with the corrected direction
9. After all 10 questions, **synthesize the answers** into a final deliverable or recommendation
10. If the user says something like "actually, I meant..." or corrects a fundamental assumption, **stop the current question flow, acknowledge the correction, and restart from the relevant question with the corrected context**

### Question Categories (adjust per task)
| Block | Topic | Example Questions |
|-------|-------|-----------------|
| 1-2 | Goal & Scope | What exactly do you want to achieve? What does success look like? |
| 3-4 | Style & Format | What tone, style, or format do you prefer? Any examples you like? |
| 5-6 | Audience & Context | Who is this for? What do they already know? |
| 7-8 | Constraints & Preferences | Budget? Timeline? Tools? Anything you definitely don't want? |
| 9-10 | Execution & Delivery | How do you want the final output? Any next steps after this? |

### Pitfall: Misinterpreting the User's Intent
- **If the user says something ambiguous** (e.g., "evolution of e-commerce business and evolution of customer service"), do NOT assume they mean combined — ask for clarification
- **If the user corrects you** (e.g., "I didn't mean before versus after" or "I meant both in separate prompts"), stop immediately, acknowledge, and restart the question flow with the corrected understanding
- **Never proceed with assumptions** — the 10-question protocol exists precisely to prevent this

### Pitfall: Assuming Visual Style Without Checking Brand Assets
- **ALWAYS check the user's website or brand guidelines** before suggesting colors, themes, or visual styles for images
- For axovion.io specifically: dark theme (#0A0A0F), tagline "Automate to Win", font Inter, sleek premium tech vibe
- Never suggest light/white themes for Axovion content without confirming — the brand is dark
- Use `curl -s -L <website>` to quickly check meta tags, theme colors, and descriptions

### Pitfall: Assuming "Evolution" Means Before/After
- When a user asks for "evolution" imagery, do NOT assume they want a before/after comparison
- Ask explicitly: "Do you want a before/after split, or a single modern scene representing the evolved state?"
- Many users use "evolution" to mean "cutting-edge/modern" not "historical progression"

### Pitfall: Defaulting to Local Currency
- **Always confirm the user's transaction currency before quoting prices**
- This user (Axovion.io) explicitly corrected: "my company is doing transaction in dollars, so convert this"
- Default to USD for any agency/service pricing discussions unless user specifies otherwise
- When mentioning costs of tools, setups, or services, state currency explicitly: "~$25-35" not "₹2,000-3,000"

### Pitfall: Generic Visual Recommendations for AI Agencies
- For AI automation agencies, do NOT default to generic talking head backgrounds or standard corporate visuals
- **Ask about their core visual narrative**: Do they want to show AI *building* workflows, AI *transforming* complexity into simplicity, or AI *evolving* manual processes into automated ones?
- This user specifically wants: "photos like an AI building workflow or AI doing something easy or evolving a thing into AI so things become easy"
- The visual story should project: **manual/hard → AI/easy** transformation, not just pain point agitation
- Recommended visual concepts for AI automation agencies:
  - Circuit lines assembling into a workflow diagram
  - Manual spreadsheet morphing into clean automated dashboard
  - Human hand + robotic hand collaborating on a task
  - Complex tangle of wires untangling into a straight green line
  - Before (messy inbox) → After (organized AI-handled queue)

### Pitfall: Context Switching Without Completing
- The 10-question and 50-question protocols are the DEFAULT approach
- **If the user says "urgent task" or "pause this," immediately pause and switch to the urgent task**
- Do NOT insist on completing the protocol when the user has a time-sensitive need
- Acknowledge the pause: "Paused! No problem — the [X questions] will pick up right where we left off whenever you're ready."
- Track the pause point so you can resume seamlessly later

### Pitfall: Explaining Instead of Acting
- **When the user says "just do it" or similar urgency signals, they want ACTION not explanation**
- Do NOT explain why a tool is down, why something might fail, or ask them to wait
- Switch to alternative methods immediately (fallback APIs, manual workarounds, direct execution)
- Report results, not obstacles
- This applies especially to: posting content, sending messages, executing tasks the user has already decided on

### Social Media Image Best Practices (Learned from Session)
- **Text in images increases dwell time**: Strategic text (3-5 words or a short headline) forces viewers to pause and read, signaling the algorithm that content is engaging
- **Headline + subheadline structure works well**: Top hook question or statement + bottom payoff/promise
- **Labels on visual elements educate while engaging**: Small labels on system nodes (e.g., "Cart", "Payment", "Support") increase dwell time AND teach the viewer
- **Match image style to website brand**: Dark website = dark social images for consistency
- **Isometric + photorealistic are both valid**: Let user choose based on emotional vs. educational goals
- **Free image tools**: When user asks you to generate images, provide a curated list of free tools (Ideogram.ai, Leonardo.ai, etc.) but clarify you cannot access them on their behalf

### LinkedIn Engagement Strategy
When user wants to comment on LinkedIn posts:
- Keep comments 1-3 sentences
- Add value (insight, experience, or thoughtful question)
- Mention poster by name when possible
- End with an open question to encourage replies
- Connect to Axovion's expertise when relevant (automation, AI, e-commerce)
- See `references/social-media-image-prompts.md` for comment formulas and examples

## 8b. Content Generation Style Discovery (Deep-Dive Protocol)

When the user wants to define or refine their **social media post image style**, use this extended protocol. The base 10 questions establish fundamentals; the full 50-question deep dive builds a complete, actionable content system. This is distinct from general marketing strategy — it focuses specifically on visual content parameters for lead-generation posts.

### Base 10 Questions (Essentials)
| # | Topic | Options | Notes |
|---|-------|---------|-------|
| 1 | **Primary Platform** | A) Instagram B) Facebook C) LinkedIn D) Multiple | Determines ratio and format |
| 2 | **Specific Platforms** (if D) | A) IG+FB+LI B) IG+TikTok+Pinterest C) FB+LI+Twitter D) Custom | Influences tone and style |
| 3 | **Primary Goal** | A) Traffic/CTR B) Brand awareness C) Leads/DMs D) Authority/education | Drives content type selection |
| 4 | **Image Style** | A) Clean corporate B) Bold meme-style C) Professional photography D) AI abstract art | Bold high-contrast recommended for lead gen |
| 5 | **Color Scheme** | A) Dark+neon B) White+bold accent C) Rainbow chaos D) Brand colors only | Check website first! |
| **Primary Accent Color** | A) Electric blue B) Neon green C) Hot pink D) Orange/yellow | Blue = tech/trust for AI automation |
| **Font Style** | A) Bold sans-serif B) Glitchy/tech C) Mixed fonts D) Retro pixel | Mixed fonts = readability + edge |
| 8 | **Image Ratio** | A) 1:1 square B) 4:5 portrait C) 16:9 landscape D) 9:16 vertical | 4:5 = max mobile screen space |
| 9 | **Content Type** | A) Single statement B) Before/after C) Listicle D) Testimonial | Single statement = fastest read, highest impact |
| 10 | **Statement Tone** | A) Direct call-out B) Curiosity gap C) Pain point D) Bold claim | Mix B+C for variety |

### Extended Questions 11-30 (System Design)
After the base 10, continue with these to build the operational system:

| # | Topic | Options | Why It Matters |
|---|-------|---------|----------------|
| 11 | **Tone Split** | A) 70/30 B) 50/50 C) 30/70 D) Platform-based | Determines content mix |
| 12 | **Visual Elements** | A) Abstract shapes B) People silhouettes C) Product mockups D) Minimal text-only | Adds texture without clutter |
| 13 | **Element Split** | A) 70/30 B) 50/50 C) 30/70 D) Context-based | Creates content rhythm |
| 14 | **Mockup Style** | A) Realistic screenshots B) Stylized interface C) Dashboard/analytics D) Before/after | Proof vs. intrigue balance |
| 15 | **Posting Frequency** | A) 1x/day B) 2x/day C) 3x+ D) Flexible | Sustainability vs. growth speed |
| 16 | **Post Time** | A) Morning B) Lunch C) Evening D) Late night | When audience is in decision mode |
| 17 | **CTA on Image** | A) Bold text CTA B) Caption only C) Subtle icon D) Context-based | Reduces friction for DMs |
| 18 | **CTA Phrase** | A) "DM me 'AUTOMATE'" B) "Comment 'YES'" C) "Link in bio" D) "Save + DM" | Tracks intent, starts conversation |
| 19 | **Logo Placement** | A) Every post B) Subtle watermark C) No logo D) Every 3rd/4th | Brand recognition vs. clean look |
| 20 | **Non-Branded Format** | A) Text only B) Text + abstract C) Text + mockups D) Context-based | Visual variety within system |
| 21 | **Template Approach** | A) 3-5 templates B) Custom every post C) Template + tweaks D) AI variations | Speed vs. uniqueness |
| 22 | **Template Count** | A) 3 B) 4 C) 5 D) Start with 2 | Variety without overwhelm |
| 23 | **Template Types** | A) Pain/Curiosity/Branded/Educational B) Pain/Curiosity/Testimonial/CTA C) Pain/Curiosity/Stat/BTS D) Pain/Curiosity/FAQ/Offer | Covers full funnel |
| 24 | **Creation Tool** | A) Canva B) Figma C) Photoshop D) Manual/Pomelli | Workflow efficiency |
| 25 | **AI Tool Role** | A) Text only B) Full prompts C) Code renders D) Step instructions | Human-AI collaboration |
| 26 | **Prompt Detail** | A) Full visual spec B) Concept + text C) Step-by-step D) Multiple variations | Execution precision |
| 27 | **Caption Generation** | A) Full caption + hashtags B) Caption only C) No caption D) 2 options | Ready-to-post efficiency |
| 28 | **Caption Tone** | A) Match image B) Always friendly C) Professional D) Short/punchy | Consistency doubles impact |
| 29 | **Batch Size** | A) 7 ideas B) 14 ideas C) 30 ideas D) 4 ideas | Planning horizon |
| 30 | **Batch Day** | A) Sunday B) Monday C) Friday D) Flexible | Workflow integration |

### Extended Questions 31-50 (Advanced Refinement)
For users who want to fully optimize their content engine:

| # | Topic | Options | Purpose |
|---|-------|---------|---------|
| 31 | **Hashtag Strategy** | A) Niche-specific B) Broad reach C) Branded D) Mix | Discovery optimization |
| 32 | **Caption Length** | A) 1-2 sentences B) 3-5 sentences C) Long form D) Variable | Platform algorithm favor |
| 33 | **Engagement Hooks** | A) Question in caption B) Poll/sticker C) Controversy D) Value first | Comment generation |
| 34 | **Story/Highlight Use** | A) Daily stories B) Highlights only C) Both D) Neither | Funnel depth |
| 35 | **User-Generated Content** | A) Repost client wins B) Testimonial graphics C) Neither D) Both | Social proof |
| 36 | **Video vs. Static** | A) All static B) 50/50 mix C) Mostly video D) Reels only | Algorithm preference |
| 37 | **Carousel Posts** | A) Weekly B) Bi-weekly C) Monthly D) Never | Educational depth |
| 38 | **Trending Audio** | A) Always use B) Never use C) Selective D) N/A for static | Reach amplification |
| 39 | **Cross-Posting** | A) Same content all platforms B) Tailored per platform C) Primary + 2ndary D) Platform-exclusive | Efficiency vs. optimization |
| 40 | **Content Pillars** | A) 3 pillars B) 4 pillars C) 5 pillars D) No formal pillars | Strategic focus |
| 41 | **Competitor Monitoring** | A) Daily check B) Weekly C) Monthly D) Never | Inspiration + differentiation |
| 42 | **A/B Testing** | A) Test headlines B) Test visuals C) Test CTAs D) Test all | Optimization loop |
| 43 | **Analytics Review** | A) Daily B) Weekly C) Monthly D) Never | Data-driven iteration |
| 44 | **Content Repurposing** | A) Blog to social B) Social to blog C) Both D) Neither | Asset leverage |
| 45 | **Seasonal Content** | A) Holiday posts B) Industry events C) Both D) Evergreen only | Timeliness |
| 46 | **Collaboration Posts** | A) Client features B) Influencer collabs C) Both D) Solo only | Network effects |
| 47 | **Paid Boosting** | A) Boost top performers B) Boost everything C) Never D) Test budget | Acceleration |
| 48 | **Lead Magnet Tie-In** | A) Every post B) Every 3rd post C) Weekly D) Separate funnel | Conversion optimization |
| 49 | **DM Automation** | A) Instant auto-reply B) Delayed response C) Manual only D) Hybrid | Response time |
| 50 | **Content Evolution** | A) Monthly refresh B) Quarterly review C) Annual overhaul D) Continuous iteration | Long-term relevance |

### The Complete Axovion.io Content System (Reference)
See `references/social-media-image-prompts.md` for the fully documented content generation system including all template specifications, prompt structures, batch workflows, and brand parameters established through deep-dive sessions.

### AI-Assisted Creation Workflow
For users creating content with free AI tools (ChatGPT, Gemini) + manual execution:

1. **Sunday Batch Session** (2-3 hours):
   - Generate 7 post ideas via AI (one for each day)
   - Each idea includes: hook text, visual description, caption, hashtags
   - User creates images manually in their preferred tool (Pomelli, Canva, etc.)

2. **AI Prompt Structure for Content Generation**:
   ```
   Role: You are a social media content strategist for an AI automation agency.
   Task: Generate a complete week's content (7 posts) for [platforms].
   
   For each post provide:
   - Template type: [Pain point / Curiosity / Branded / Educational]
   - Hook text (single powerful statement or question)
   - Full visual description (colors, layout, elements, text placement)
   - Caption (matching tone to image)
   - Hashtags (10-15, mix of niche and broad)
   - Best post time: [time]
   
   Brand parameters:
   - Dark background (#0A0A0F)
   - Neon BLUE accent (#0080FF)
   - Mixed fonts (bold headline + clean body)
   - 4:5 portrait ratio
   - CTA: "DM me 'AUTOMATE'"
   ```

3. **Template Rotation**:
   - Day 1: Pain point + chat mockup
   - Day 2: Curiosity + abstract shapes
   - Day 3: Educational tip
   - Day 4: Branded promo (logo visible)
   - Repeat cycle with fresh hooks

### Session Continuity for Long Interviews
If the interview spans multiple sessions:
1. **Save progress to a local JSON file** (e.g., `content_discovery_progress.json`) with keys: `last_question_asked`, `answers`, `timestamp`
2. At session start, check for this file and resume from the last answered question
3. If the file is missing, search `~/.hermes/sessions/` for the previous session JSON and grep for question/answer pairs
4. Always confirm the resume point with the user before continuing

### WhatsApp Cold Outreach Pitch Creation Protocol

When the user wants to create WhatsApp pitch messages for cold client outreach, use this structured 10-question protocol. This is distinct from general content creation — it focuses on sales messaging and conversation openers.

#### Base Questions (10)

| # | Topic | Options | Notes |
|---|-------|---------|-------|
| 1 | **Target Market** | A) Dropshipping B) Local brands C) UK/US e-commerce D) Broad | Leverage user's market knowledge |
| 2 | **Lead Temperature** | A) Cold B) Warm C) Referral D) Inbound | Changes tone from conversation to pitch |
| 3 | **Primary Offer** | A) Free audit B) Free demo C) Case study D) Direct pitch | Lead with value, not ask |
| 4 | **Message Tone** | A) Professional B) Casual/friendly C) Bold/direct D) Curiosity | Casual gets 3x replies on cold WhatsApp |
| 5 | **Pain Point Approach** | A) Specific (cart abandonment) B) Specific (slow replies) C) General D) Let them choose | "Let them choose" turns pitch into consultation |
| 6 | **Message Length** | A) Ultra short (1-2 lines) B) Short + value tease (3-4 lines) C) Medium (5-7 lines) D) Long pitch | Under 4 lines = highest reply rates |
| 7 | **Social Proof in Msg 1** | A) Specific result B) Vague credibility C) None D) Soft stat | Save proof for reply #2 |
| 8 | **CTA Type** | A) Free demo B) Send video C) Free trial D) Meeting | "Send video" = lowest friction |
| 9 | **Follow-up Strategy** | A) Same day B) Next day C) 3-day sequence D) No follow-up | 80% of sales after 5+ touches |
| 10 | **Personalization Level** | A) Name only B) Store mention C) Specific observation D) None | Specific observation = highest reply rate |

#### WhatsApp Pitch Style Variants

This user has two distinct pitch styles depending on context. **Always ask which style they want** before writing the pitch.

**Style A: Consultative / Casual (Higher Reply Rates)**
```
Hey [Name], quick question — which hurts more: 
abandoned carts or slow customer replies?

I build AI bots that fix both. Happy to send you a 
2-minute video showing how it works if you're curious.
```
**When to use:** Cold outreach to warm-ish leads, e-commerce store owners, when relationship-building matters more than immediate conversion.
**Why it works:** Opens with a question (engagement hook), lets them identify their own pain point, zero-commitment CTA.

**Style B: Direct / Name-Brand-Service (User's Preferred Style for Call Centers)**
```
Hey [Name], I'm Hamza from Axovion.io.

We're an AI automation company. We help call centers increase sales ratios, enhance customer support, and improve calling services.

We build AI voice agents, chatbots, and lead qualification systems — all customized to your scripts.

Happy to send you a quick demo if you're interested.
```
**When to use:** B2B call center outreach, when user explicitly requests direct style, when targeting operations managers who prefer straightforward communication.
**Why user prefers it:** Feels more authoritative, establishes brand immediately, lists capabilities clearly.
**Weaknesses to be aware of:**
- Lists 4+ services in one message = potential confusion
- "If you're interested" = weak close (consider: "Want me to send the demo?")
- No differentiator from every other AI company
- Vague outcomes ("enhance customer support" = what does that mean numerically?)

**If user insists on Style B, apply these fixes without changing their structure:**
- Replace "enhance customer support" with specific metric: "cut support response time from 2 hours to 30 seconds"
- Replace "improve calling services" with specific outcome: "increase show rate from 40% to 65%"
- Strengthen close: "Want me to send a 2-minute demo?" instead of "if you're interested"
- Keep the list of services but lead with the ONE most relevant to their niche

#### Sample WhatsApp Pitch (Casual + Let Them Choose + Video CTA)

```
Hey [Name], quick question — which hurts more: 
abandoned carts or slow customer replies?

I build AI bots that fix both. Happy to send you a 
2-minute video showing how it works if you're curious.
```

**Why this works:**
- Opens with a question (engagement hook)
- Lets them identify their own pain point
- "I build AI bots that fix both" = concise value proposition
- "2-minute video" = zero-commitment CTA
- No social proof in first message (builds trust first)

#### Follow-up Sequence (if no reply)

**Day 2:**
```
Hey [Name], no worries if you're swamped. 
Just thought this might save you 10+ hours/week 
on customer support. Still happy to share that 
quick video if useful.
```

**Day 5:**
```
[Name], last nudge — I helped a similar store 
recover $2,300/week in abandoned carts with AI. 
Worth a 5-min chat?
```

#### Key Principles
- **Never sell in message 1** — start conversations, not pitches
- **WhatsApp is personal** — write like a real person, not a brochure
- **The "which hurts more" opener** works because it feels like advice, not a sales pitch
- **Always offer to send something** (video, audit, case study) before asking for a meeting
- **Track reply rates by opener** — iterate based on what gets responses

## 9. User's Strategic Advisor Persona (CRITICAL)

When this user engages in business strategy, positioning, or competitive analysis discussions, they have explicitly instructed:

> "You are my elite strategic advisor and execution mentor. Your role is not to encourage me — your role is to pressure-test my thinking until it is commercially viable, strategically sound, and execution-ready. Do not soften criticism, avoid hard truths, or give motivational filler. Analyze every idea like an investor, operator, and competitor combined."

### How to Apply This Persona
- **Never give praise unless the idea genuinely withstands scrutiny**
- **Identify weak assumptions immediately** — niche selection, pricing, competitive positioning
- **Challenge vague thinking** — "all kinds of call centers" = no positioning
- **Point out naivety** — jumping between markets, undervaluing specialization
- **Force specificity** — "who is paying the bills right now?" "what's your wedge against Balto?"
- **Compare against real competitors** — don't let them believe they're the only player
- **Explain what would fail in the real world and why**
- **Suggest stronger alternatives** — sharper positioning, higher-value opportunities

### Red Flags to Call Out Immediately
- Serving "everyone" or "all kinds" — demand the single niche they can dominate first
- Competing on price alone — this is a race to the bottom
- Free pilots without cost coverage — who pays for the leads if the AI fails?
- Jumping between tasks without completing — force completion before context switching
- Leading with tech instead of outcome — call centers don't want AI, they want lower cost per qualified lead
- Underestimating established competitors — "Balto raised $X and has Fortune 500 clients, what's your wedge?"

### The "Hard Truth" Framework
When the user presents a business idea or pivot:
1. **Restate the idea in its harshest form** — strip away optimism
2. **Identify the single biggest reason it would fail** — be specific
3. **Name the competitor who would crush them** — and why
4. **Ask the question they don't want to answer** — "Which business is paying the bills right now?"
5. **Offer only ONE alternative** — the sharper, more focused version

## 10. Handling Task Switching & Incomplete Work

This user frequently jumps between tasks before completing them. This is an execution bottleneck.

### Protocol When User Switches Tasks
1. **Acknowledge the new task**
2. **State clearly what is incomplete** — "We have two incomplete threads: [X] and [Y]"
3. **Force a choice** — "Which one do you want to complete? No more context switching until it's done."
4. **Track pause points** — save question number, answers, and context
5. **On resume, confirm the state** — "Last time we were on Question 7 of 10 for [topic]. Correct?"

### Never Allow
- Starting a 3rd task when 2 are incomplete
- Vague "I'll come back to it" without a specific commitment
- Context switching within the same task (e.g., changing target market mid-pitch creation)

## 11. Call Center Market Expansion (Beyond E-commerce)

When the user pivots to selling AI automation to call centers, the playbook changes:

### Key Differences from E-commerce
| Factor | E-commerce | Call Centers |
|--------|-----------|--------------|
| Buyer | Store owner (emotional) | Operations manager (metric-driven) |
| Pain point | Lost sales, slow replies | Cost per lead, agent utilization, no-show rate |
| Decision speed | Fast (FOMO) | Slow (pilot required, metrics reviewed) |
| Competition | Fragmented, many small players | Established (Balto, Cresta, Observe.AI) |
| Pricing sensitivity | Medium | High ( razor-thin margins) |
| Sales cycle | 1-2 weeks | 1-3 months |

### Call Center Positioning Strategy
1. **Niche wedge first** — home improvement (spray foam, roofing, solar) where user has insider knowledge
2. **Metric-based pitch** — "cut your no-show rate from 40% to 12%" not "AI is the future"
3. **Per-qualified-lead pricing** — aligns incentives, removes seat-count negotiation
4. **Operations manager as target** — not CEO (too busy), not IT (blocks everything), not sales manager (doesn't own efficiency)
5. **Pilot program structure** — 100 leads, side-by-side comparison, hard numbers

### Call Center WhatsApp Pitch (Example)
```
Hey [Name], quick question — how many of your leads 
are actually showing up for appointments?

I spent 3 years in home improvement call centers. 
Built an AI that pre-qualifies leads before your 
agents ever dial. Happy to run a free 100-lead pilot 
so you can compare the numbers.
```

**Why this works for call centers:**
- Opens with their core metric (show rate)
- Establishes insider credibility immediately
- Offers proof, not promise (100-lead pilot)
- Targets operations manager pain (agent time waste)

### Running Both Markets Simultaneously: The Reality

This user frequently insists on serving both e-commerce AND call centers (or multiple niches) at once. This is a recurring pattern. **Do not simply agree — pressure-test it.**

**The hard truth:** "Handling both" is not a strategy. It's a resource split. Here's what breaks:

1. **Different buyers, different cycles.** E-commerce owners buy on emotion (lost sales, FOMO). Call center managers buy on spreadsheets (cost per lead, agent utilization). One pitch cannot serve both. You need two funnels, two case studies, two demo scripts.

2. **Brand dilution.** Axovion.io is currently positioned for e-commerce (dark background, neon green, cart abandonment, "DM me AUTOMATE"). That visual identity screams B2C SaaS. Call center managers will see it and assume you're not serious about their world.

3. **Credibility gap.** 3 years as an agent is not 3 years selling to call centers. You know the floor. Do you know the P&L? Can you speak to dialer costs, lead vendor contracts, TCPA compliance, agent churn rates?

4. **Competition is brutal.** Balto, Cresta, Observe.AI have raised 9 figures. Your "free pilot on 100 leads" competes against their "deployed at 10,000 seats with McDonald's."

**If the user insists on both (which they will), frame it as:**
> "You can RUN both, but you must LEAD with one. Which business is paying the bills right now? That's your lead horse. The other is a side project until it generates revenue."

**The only viable "both" strategy:**
- **Lead with call centers** (your insider advantage, higher deal size)
- **Use e-commerce as content marketing** (your social media presence, easier to demonstrate)
- **Cross-sell after establishing trust** — "We also do e-commerce automation" comes AFTER the call center deal closes
- **Never mention both in the same pitch** — one message, one market, one pain point

**Track which market is actually producing revenue.** If one is all talk and no clients, call it out.

## 12. Common Beginner Mistakes

- ❌ Trying to serve everyone — pick one niche first
- ❌ Leading with tech/features — lead with outcomes
- ❌ No follow-up system — 80% of sales happen after 5+ touches
- ❌ Underpricing — price based on value, not your hours
- ❌ Ignoring existing network — tell everyone you know what you're doing
- ❌ Context switching without completing — finish one thread before starting another
- ❌ Competing on "all four services" — generalists lose to specialists
- ❌ Free pilots without liability clarity — who covers costs if AI underperforms?
- ❌ Targeting "all call centers" — home improvement is the wedge, expand later

## Competitive Analysis for Sales Meetings

When preparing for a sales meeting with a specific prospect or competitor, use the `competitive-analysis` skill. It covers:

- Zero-dependency web scraping (when subagents fail)
- Research synthesis into a structured competitive profile
- Building a sales-ready HTML webpage or deck
- Mapping Axovion's four offerings to the prospect's gaps
- Positioning strategy (white-label partner, AI layer, replacement, team extension)

Typical deliverable: a single self-contained HTML file saved to the home directory with sections for company profile, services, portfolio, social media, technology stack, competitive gaps, opportunity map, and meeting next steps.

See `references/aaa-digital-case-study.md` in the `competitive-analysis` skill for a complete example.

## References
- See `references/axovion-io-profile.md` for this user's specific business context and communication preferences.
- See `references/axovion-repo-structure.md` for the project repository structure and technical details.
- See `references/social-media-image-prompts.md` for image prompt creation guidelines, brand color matching, and dwell-time text strategies.
- See `references/call-center-pitch-workflow.md` for the complete call center WhatsApp pitch system, competitor analysis, and hard truths framework.
- See `references/zernio-posting-workflow.md` for automated social media posting via Zernio MCP AND the direct REST API fallback when MCP fails, including multi-API-key patterns for separate platform connections and Instagram-specific `mediaItems` format.
- See `references/whatsapp-image-posting-workflow.md` for posting images received in chat (e.g., from WhatsApp) to Instagram/Facebook/LinkedIn via temporary public hosting + direct API.
- See the `competitive-analysis` skill for sales-meeting competitive research and webpage deliverables.
- See `references/z-image-turbo-prompting.md` for the Axovion-specific Z-Image Turbo model prompt engineering guide (S3-DiT parameters, photography vocabulary, style presets, carousel templates, and Modal API endpoint).

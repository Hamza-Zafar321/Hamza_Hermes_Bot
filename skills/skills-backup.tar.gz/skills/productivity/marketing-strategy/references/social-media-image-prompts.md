# Social Media Image Prompt Creation — Reference Guide

## Axovion.io Content Generation System (Complete)

The following parameters were established through structured 50-question discovery sessions. Use this as the canonical reference when creating content for Axovion.io.

### Visual Identity
| Parameter | Decision | Rationale |
|-----------|----------|-----------|
| **Platforms** | Facebook, LinkedIn, Twitter/X | B2B + community + professional reach |
| **Goal** | Lead generation / DMs | Direct response over awareness |
| **Image Style** | Bold, high-contrast meme-style | Scroll-stopping power |
| **Background** | Dark (#0A0A0F base) | Matches website, premium tech feel |
| **Primary Accent** | Neon BLUE (#0080FF or similar) | Tech, trust, AI signal |
| **Font** | Mixed — bold glitchy/tech headline + clean sans-serif body | Edge + readability |
| **Ratio** | 4:5 portrait | Max mobile screen real estate |
| **Content Type** | Single powerful statement or question | Fastest read, highest impact |
| **Tone Mix** | 50% Pain point agitation / 50% Curiosity gap | Balanced emotional + intrigue |
| **Visual Elements** | Context-based: abstract geometric for curiosity, product mockups for pain | Natural content rhythm |
| **Mockup Style** | Realistic WhatsApp/Instagram DM screenshots | Familiar, relatable, achievable |
| **Posting Frequency** | 1x per day | Consistency without burnout |
| **Post Time** | Evening (6-9 PM) | Decision-making mode, planning mindset |
| **CTA** | Bold on-image: "DM me 'AUTOMATE'" | Direct, tracks intent, starts conversation |
| **Logo Placement** | Every 3rd/4th post only | Brand recognition without clutter |
| **Non-Branded Format** | Mix: pain posts get chat screenshots, curiosity gets abstract shapes | Visual variety within system |
| **Templates** | 4 reusable templates | Speed, consistency, scalability |
| **Creation Tool** | AI (ChatGPT/Gemini) for prompts + manual in Pomelli | Free tools, full creative control |
| **Batch Day** | Sunday | 2-3 hour weekly prep session |
| **Batch Size** | 7 posts (1 week) | Fresh, pivot-friendly planning |

### The 4 Templates
| Template | Purpose | Visual Style | When to Use |
|----------|---------|--------------|-------------|
| **Pain Point + Chat Mockup** | Agitate pain, prove solution | Realistic DM screenshot + bold hook text | Days when targeting active pain |
| **Curiosity + Abstract** | Create intrigue, drive DMs | Dark background + geometric nodes/circuits + hook question | Days when building intrigue |
| **Branded Promo** | Build brand recognition | Logo visible + tagline + value prop | Every 4th post (logo placement) |
| **Educational Tip** | Establish authority | Clean layout + single insight + subtle branding | Authority-building days |

### Template Rotation (Weekly Example)
| Day | Template | Tone | Logo? |
|-----|----------|------|-------|
| Monday | Pain Point + Chat | Agitation | No |
| Tuesday | Curiosity + Abstract | Intrigue | No |
| Wednesday | Educational Tip | Authority | No |
| Thursday | Pain Point + Chat | Agitation | No |
| Friday | Branded Promo | Value | **Yes** |
| Saturday | Curiosity + Abstract | Intrigue | No |
| Sunday | Pain Point + Chat | Agitation | No |

### Tone Formulas
**Pain Point Agitation (50% of posts):**
- "Tired of losing sales while you sleep?"
- "Still replying to DMs manually at midnight?"
- "Your competitors answer in 2 seconds. You answer in 2 hours."
- "Every missed DM is a missed sale."

**Curiosity Gap (50% of posts):**
- "This 1 automation got 47 leads in 24 hours..."
- "What if your store sold while you slept?"
- "The e-commerce brands winning 2025 all have this 1 thing in common."
- "I replaced a 3-person team with 1 bot. Here's how..."

### Content Rules
1. Every post must have **text overlay** — no text-free images
2. Text forces dwell time (2-3+ seconds), signaling algorithm engagement
3. Structure: **Bold headline** (top/center) + **subtle subheadline** (bottom) OR single centered statement
4. Mockup posts only for pain-point content; abstract visuals only for curiosity content
5. All images must be dark-themed with neon green accent — never light/white themes
6. CTA "DM me 'AUTOMATE'" on every post image
7. Logo only appears on branded promo posts (every 3rd-4th post)

## AI-Assisted Creation Workflow

### Sunday Batch Session (2-3 hours)
1. **Generate 7 post ideas** via ChatGPT/Gemini
   - Each includes: template type, hook text, full visual description, caption, hashtags
2. **Create images manually** in Pomelli (or user's preferred tool)
   - Use AI-generated visual descriptions as exact specifications
3. **Schedule or draft** for the week
   - Post daily at 6-9 PM

### AI Prompt for Weekly Content Generation
```
Role: You are a social media content strategist for Axovion.io, an AI automation agency.
Task: Generate 7 complete posts for this week (Monday-Sunday).

For each post provide:
- Day: [Monday-Sunday]
- Template: [Pain Point + Chat / Curiosity + Abstract / Branded Promo / Educational Tip]
- Hook text (single powerful statement or question, max 10 words)
- Full visual description:
  * Background: dark #0A0A0F
  * Accent: neon green #00FF41
  * Layout: [describe element positions, text placement, mockup details]
  * Font: bold headline + clean sans-serif subtext
  * Ratio: 4:5 portrait
  * CTA placement: bottom center "DM me 'AUTOMATE'"
- Caption (3-5 sentences, matching tone to template)
- Hashtags (10-15, mix of niche: #ecommerce #aiautomation #chatbot and broad: #business #entrepreneur)
- Best post time: 6-9 PM

Brand voice: Bold, direct, beginner-friendly. No jargon.
Target: E-commerce store owners doing $10K-$500K/year.
```

### Visual Description Detail Level
When generating image prompts for manual creation, include:
- **Exact hex codes**: Background #0A0A0F, accent #00FF41, text white #FFFFFF
- **Element positions**: "Headline centered top 20%, subheadline bottom 15%, CTA bottom 5%"
- **Font sizes**: "Headline: 48-64px bold, Subheadline: 24-32px regular"
- **Spacing**: "Padding 40px from edges, line height 1.2"
- **Effects**: "Neon glow on accent elements, subtle drop shadow on text"
- **Mockup details** (if applicable): "Realistic WhatsApp chat bubble, green sender bubbles, gray receiver bubbles, timestamp 2:34 PM"

## Axovion.io Brand Identity (from website metadata)
| Element | Value |
|---------|-------|
| Theme Color | `#0A0A0F` (very dark, almost black) |
| Tagline | "Automate to Win" |
| Description | "Automate repetitive workflows in days, not quarters" |
| Font | Inter (modern, clean, sans-serif) |
| Vibe | Dark, sleek, premium tech |
| OG Title | "Axovion.io | AI Automation Agency — Automate to Win" |
| OG Description | "Automate repetitive workflows in days, not quarters." |

## Axovion.io Brand Identity (from website metadata)
| Element | Value |
|---------|-------|
| Theme Color | `#0A0A0F` (very dark, almost black) |
| Tagline | "Automate to Win" |
| Description | "Automate repetitive workflows in days, not quarters" |
| Font | Inter (modern, clean, sans-serif) |
| Vibe | Dark, sleek, premium tech |
| OG Title | "Axovion.io | AI Automation Agency — Automate to Win" |
| OG Description | "Automate repetitive workflows in days, not quarters." |

## Image Prompt Structure for Gemini/AI Image Generators

### The 5-Part Formula
1. **Style + Format** — Isometric 3D render, photorealistic, flat illustration, etc.
2. **Subject/Scene** — What is being depicted
3. **Color Scheme** — MUST match brand (for Axovion: dark #0A0A0F base + accent colors)
4. **Lighting + Atmosphere** — Soft ambient, neon glow, cinematic, etc.
5. **Text/Labels** — Headlines, subheadlines, node labels (if any)

### Example: E-Commerce AI Automation (Isometric)
```
Isometric 3D render of a futuristic AI-powered e-commerce ecosystem 
on a transparent glass platform with reflections. Multiple glowing system 
nodes connected by luminous lines: shopping cart, payment gateway, 
email envelope, social media ads megaphone, inventory boxes, and 
chatbot head. Each node has a small subtle label. Soft ambient 
lighting with gentle glows from AI connection lines. Dark background 
#0A0A0F with blue and greenish neon accents. Modern, technical, 
premium, next-level quality. Highly detailed, professional tech 
visualization.
```

### Example: Dark Theme Social Post with Text
```
Dark futuristic tech visualization on #0A0A0F background. Glowing 
neon network of connected AI systems in blue and green. Bold white 
text headline: "Stop Working Harder. Start Automating Smarter." 
Subtle subheadline: "Automate repetitive workflows in days, not 
quarters." Soft ambient lighting, premium sleek aesthetic, 
professional quality, no clutter.
```

## Key Principles

### Text in Images — Dwell Time Strategy
- **Why it works**: Text forces viewers to pause and read, increasing dwell time (2-3+ seconds), which signals algorithms that content is engaging
- **How much text**: 3-5 words for a headline, or small labels on visual elements
- **Placement**: Top for hook questions, bottom for taglines/promises, beside nodes for educational labels
- **Font style**: Match brand font if possible (Inter for Axovion), clean sans-serif

### Color Matching
- ALWAYS check user's website first: `curl -s -L <website> | grep -i 'theme-color\|og:image\|description'`
- For Axovion: Dark base (#0A0A0F) + neon blue/green accents
- Never assume light/white themes for tech brands

### When User Says "Evolution"
- Ask explicitly: "Do you want before/after comparison, or a single modern scene showing the evolved state?"
- Many users mean "cutting-edge/modern" not "historical progression"
- If before/after: split-screen or timeline layout
- If modern only: single scene with advanced tech elements

### Layout Options for Technical Images
| Layout | Best For | Example |
|--------|----------|---------|
| Split-screen | Before/after comparisons | Old manual process vs. AI automation |
| Network/Nodes | Showing connected systems | E-commerce ecosystem with linked components |
| Timeline | Step-by-step progression | Customer journey or implementation phases |
| Central Focus | Single powerful concept | AI brain with radiating connections |
| Glassmorphism | Premium modern look | Floating cards with blur/transparency effects |

## Advanced Prompt Techniques (Learned from Sessions)

### Building Complex Prompts — The 10-Question Method
When a user wants a "next level" image, use the 10-question protocol to build the prompt collaboratively:
1. Ask about evolution type (before/after vs. modern only)
2. Ask about art style (isometric, photorealistic, 3D render, flat)
3. Ask about layout (split-screen, timeline, network, central focus)
4. Ask about color scheme (always check website first!)
5. Ask about specific elements/subject matter
6. Ask about lighting style
7. Ask about text/labels (headlines, subheadlines, node labels)
8. Ask about font/text style (neon glow, clean sans-serif, etc.)
9. Ask about background environment
10. Ask about final details (particles, grid lines, logo, etc.)

### Example: Complete Axovion Dark Theme Prompt (Built via 10 Questions)
```
Dark futuristic tech visualization on deep black background #0A0A0F. 
Bold neon glowing headline text at top: "Stop Working Harder. Start 
Automating Smarter." in gradient blue-to-purple glow. Center: Network 
of clean glowing hexagon nodes connected by luminous gradient 
blue-to-purple lines. Each hexagon has a small subtle label: Support, 
Leads, Booking, Follow-up, Content. Floating particles and sparks 
around the nodes for energy and movement. Subheadline at bottom in 
softer neon glow: "Automate repetitive workflows in days, not quarters." 
Premium, sleek, modern AI aesthetic. No human figures. Highly detailed, 
8K quality, professional dark tech visualization.
```

### Free AI Image Generation Tools (When User Asks)
If the user wants you to create images but you don't have image generation tools configured:

| Tool | Free Tier | Best For | Notes |
|------|-----------|----------|-------|
| **Gemini (Google)** | Included with free Google account | General use | User types prompt directly in chat |
| **Microsoft Copilot** | Free with Microsoft account | General use | DALL-E powered, good quality |
| **Leonardo.ai** | ~150 credits/day | Tech/futuristic images | Great for isometric and 3D |
| **Ideogram.ai** | Free tier available | Text-in-image accuracy | BEST for images with text/labels |
| **Playground AI** | Limited free generations | Fast results | Good for quick iterations |
| **Pollinations.ai** | Unlimited free | Experimental/artistic | Open source, no signup required |

**Recommendation**: Ideogram.ai for any image containing text (headlines, labels) — it renders text most accurately.

**Important**: You cannot set up or access these tools on behalf of the user. Provide the list and let them choose and sign up themselves.

### LinkedIn Comment Strategy
When a user wants to comment on a LinkedIn post:
1. Ask what the post is about (topic/industry)
2. Ask what their goal is (build relationship, show expertise, get noticed, start conversation)
3. Ask about tone (professional, friendly, thought-provoking, supportive)
4. Craft a comment that:
   - Adds value (insight, experience, question)
   - Is 1-3 sentences max (LinkedIn favors brevity)
   - Mentions the poster by name if possible
   - Ends with a question or open loop to encourage replies

**Example comment formulas:**
- "Great point, [Name]. I've seen similar results with [specific example]. Have you tried [related approach]?"
- "This resonates. The shift from [old way] to [new way] is exactly what we're seeing with our clients at Axovion."
- "Interesting perspective. I'd add that [additional insight]. What's been your experience with [related topic]?"

## Common Corrections from Sessions
1. "I meant separate prompts" → Never assume combined when user mentions multiple topics
2. "I didn't mean before/after" → Clarify "evolution" intent before designing
3. "Check my website" → Always verify brand colors/style before suggesting visuals
4. "Add text for dwell time" → Strategic text increases engagement; pure visuals may feel empty
5. "Find free tools" → Provide curated list but clarify you cannot access them on user's behalf

# Call Center WhatsApp Pitch Workflow

## Session Context
Date: May 2026
User: Muhammad Hamza Zafar, Axovion.io
Pivot: From e-commerce AI automation to call center AI automation
User's instruction: "Elite strategic advisor" mode — pressure-test, no softening

---

## The Completed 10-Question Protocol (Call Center Version)

### Answers Captured
| Q# | Topic | User's Answer | Recommendation Given |
|----|-------|--------------|---------------------|
| 1 | Services offered | All four (AI voice, chatbots, lead qual, audits) | **Flagged as red flag** — generalist positioning |
| 2 | Target type | Both outbound + inbound | **Flagged as dilution** — pick one entry point |
| 3 | Primary offer | Free pilot on 100 leads | Approved with caveats (cost liability) |
| 4 | Script handling | Hybrid (templates + 1-hour customization) | Approved |
| 5 | Niche focus | Home improvement (but wants all) | **Overruled** — home improvement is the wedge |
| 6 | Pricing model | Per-qualified-lead | Approved — aligns incentives |
| 7 | Decision-maker | Operations manager | Approved |
| 8 | Message hook | Pain point question (show rate) | Approved |
| 9 | Message tone | Casual/friendly | Approved |
| 10 | Social proof in msg 1 | None (save for reply #2) | Approved |

---

## The Final WhatsApp Pitch (Call Center → Operations Manager)

```
Hey [Name], quick question — how many of your leads 
are actually showing up for appointments?

I spent 3 years in home improvement call centers. 
Built an AI that pre-qualifies leads before your 
agents ever dial. Happy to run a free 100-lead pilot 
so you can compare the numbers.
```

### Why This Works
- **Question opener** — forces them to confront a metric they know is bad
- **Insider credibility** — "3 years in home improvement call centers" = instant trust
- **Specific offer** — "100-lead pilot" = tangible, measurable, low-risk
- **Metric-driven** — "compare the numbers" speaks operations manager language
- **No tech jargon** — "AI that pre-qualifies" not "LLM-powered conversational agent"

---

## Follow-up Sequence (If No Reply)

### Day 2
```
Hey [Name], no worries if you're swamped. Just ran 
a pilot for a roofing call center — their show rate 
went from 31% to 67% in two weeks. Happy to share 
the breakdown if useful.
```

### Day 5
```
[Name], last nudge — I know lead vendors charge you 
$40-80 per raw lead. What if you only paid for the 
ones that actually showed up? Worth a 5-min chat?
```

---

## Hard Truths Delivered in This Session

1. **"All four services" is desperation, not positioning.**
   - Call centers buy specialists. Pick one entry point.

2. **"Both outbound and inbound" means you understand neither deeply.**
   - Your 3-year outbound background is your only unfair advantage.

3. **Free pilot on 100 leads has hidden costs.**
   - Who pays for the leads if your AI fails? What's the liability?

4. **You're leading with tech, not outcome.**
   - Call center owners don't want AI. They want lower cost per qualified lead.

5. **Competition is brutal and established.**
   - Balto, Cresta, Observe.AI have 9-figure funding and Fortune 500 logos.
   - Your wedge: home improvement niche + speed + no contracts.

6. **"Handling both" (e-commerce + call centers) is a resource split.**
   - Different buyers, different cycles, different pitches.
   - Pick one. Dominate it. Then expand.

---

## User's Response Patterns (For Future Sessions)

- **Tends to agree with recommendations but then expands scope** ("Yes, option 1, but we target all")
- **Jumps between tasks before completing** — needs forced completion
- **Responds well to hard truths** — does not get defensive
- **Wants specificity** — vague answers get challenged
- **Operates in USD** — never quote in local currency

---

## Key Metrics for Call Center Pilots

| Metric | Before AI | After AI | Target Improvement |
|--------|-----------|----------|-------------------|
| Show rate | 25-35% | 55-70% | +20-30 points |
| Cost per qualified lead | $80-120 | $40-60 | -40-50% |
| Agent talk time | 2.5 hrs/day | 4+ hrs/day | +60% |
| No-show rate | 40-50% | 15-25% | -20-30 points |

---

## Competitor Landscape (Home Improvement Call Centers)

| Competitor | Strength | Weakness | Axovion Wedge |
|------------|----------|----------|---------------|
| Balto | Enterprise scale, AI coaching | Expensive, slow deploy, generic | Niche focus, speed, price |
| Cresta | Real-time guidance | Requires massive data | Pre-qualification focus |
| Observe.AI | Conversation analytics | Post-call, not real-time | Real-time qualification |
| Convoso | Dialer + CRM | No AI qualification | AI layer on top |
| Generic chatbot tools | Cheap | Not built for calls | Call-center-native |

---

## Next Steps (If User Resumes)

1. **Force niche commitment** — home improvement only for first 3 clients
2. **Define pilot terms** — who pays for leads, success criteria, duration
3. **Build case study template** — before/after metrics, testimonial format
4. **Create operations manager LinkedIn outreach** — connection request + follow-up
5. **Price anchoring** — what does a qualified lead cost them now vs. with AI?

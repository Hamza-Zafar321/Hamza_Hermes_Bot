# Zernio Social Media Automation Workflow

Reference guide for automating LinkedIn, Facebook, Instagram, Twitter/X, and other platform posting via Zernio's MCP server from within Hermes Agent.

## Prerequisites

1. Zernio MCP configured in `~/.hermes/config.yaml` (see `native-mcp` skill, `references/zernio.md`)
2. Social accounts connected at zernio.com
3. API key from zernio.com/dashboard/api-keys

## Quick Reference: Posting with Image

### Step 1: Make Image Publicly Accessible

Zernio's `media_urls` parameter requires **publicly accessible HTTP(S) URLs**. Local file paths will NOT work.

**One-shot tunnel pattern:**
```bash
# 1. Copy image to temp dir
mkdir -p /tmp/zernio_upload && cp /path/to/image.jpg /tmp/zernio_upload/post.jpg

# 2. Start local HTTP server (background)
python3 -c "
import subprocess, time
p = subprocess.Popen(
    ['python3', '-m', 'http.server', '8765', '--directory', '/tmp/zernio_upload'],
    stdout=open('/tmp/server.log','w'), stderr=subprocess.STDOUT
)
time.sleep(2)
print('Server PID:', p.pid)
"

# 3. Expose via tunnel
python3 -c "
import subprocess, time
p = subprocess.Popen(['lt', '--port', '8765'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
time.sleep(6)
print(p.stdout.readline().strip())
"
# Output: your url is: https://xxxx-yyyy.loca.lt

# 4. Verify accessibility
curl -sI https://xxxx-yyyy.loca.lt/post.jpg
```

**Prerequisites for tunnel:** `npm install -g localtunnel`

### Step 2: Discover Account IDs

```bash
hermes chat -q "Use mcp_zernio_accounts_list"
```

Note the `account_id` for each platform you want to post to.

### Step 3: Publish

**LinkedIn:**
```bash
hermes chat -q "Use mcp_zernio_posts_publish_now to publish to linkedin with account_id <ID>. Content: '<caption>'. media_urls: 'https://tunnel-url/post.jpg'"
```

**Facebook:**
```bash
hermes chat -q "Use mcp_zernio_posts_publish_now to publish to facebook with account_id <ID>. Content: '<caption>'. media_urls: 'https://tunnel-url/post.jpg'"
```

**Cross-post to multiple platforms:**
```bash
hermes chat -q "Use mcp_zernio_posts_cross_post with platforms 'linkedin,facebook', content '<caption>', media_urls 'https://tunnel-url/post.jpg'"
```

## Key Tools

| Tool | Purpose |
|------|---------|
| `mcp_zernio_posts_publish_now` | Immediate publish |
| `mcp_zernio_posts_create` | Draft or scheduled post |
| `mcp_zernio_posts_cross_post` | Multi-platform simultaneous post |
| `mcp_zernio_posts_list` | List posts by status |
| `mcp_zernio_accounts_list` | List connected accounts |

## Pitfalls

1. **Duplicate content blocked**: Zernio rejects identical content to the same account within 24 hours. Tweak copy if reposting.
2. **Local paths rejected**: `media_urls` must be public HTTP(S) URLs. No `/home/user/...` paths.
3. **Multi-account ambiguity**: If multiple accounts exist on one platform, pass `account_id` explicitly.
4. **Tunnel expiry**: `localtunnel` URLs expire when the process exits. For scheduled posts, use a persistent hosting solution (S3, CDN, etc.).
5. **Image size limits**: LinkedIn 8MB, Facebook 4MB, Instagram 8MB. Compress before posting if needed.

## Automation Integration

This workflow can be embedded in cron jobs for daily automated posting:

```yaml
# Example cron job config
cronjob:
  schedule: "0 9 * * *"
  prompt: "Generate today's Axovion brand awareness post, create the image, upload via tunnel, and publish to LinkedIn and Facebook using Zernio MCP tools"
```

For fully automated image hosting, consider:
- AWS S3 presigned URLs
- Cloudflare R2
- GitHub raw content URLs (for static assets)
- Any persistent public CDN

## MCP Failure Fallback: Direct REST API

When Zernio MCP tools timeout or return "unreachable after 4 consecutive failures," use the user's API key directly against the Zernio REST API.

### When to Use Fallback
- MCP calls timeout after 180s
- `mcp_zernio_accounts_list` returns unreachable/error
- User says "just do it" and expects action, not explanations about MCP being down

### Fallback Steps

**1. Get account IDs via curl:**
```bash
curl -s -H "Authorization: Bearer <API_KEY>" https://api.zernio.com/v1/accounts | python3 -m json.tool
```

**2. Write post payload to JSON file** (avoids shell escaping hell with quotes/newlines):
```bash
cat > /tmp/post_payload.json << 'EOF'
{
  "content": "Your post text here.\n\nWith newlines.",
  "platforms": [
    {"platform": "facebook", "accountId": "<FB_ACCOUNT_ID>"},
    {"platform": "linkedin", "accountId": "<LI_ACCOUNT_ID>"}
  ],
  "publishNow": true
}
EOF
```

**3. Publish via curl:**
```bash
curl -s -X POST https://api.zernio.com/v1/posts \
  -H "Authorization: Bearer <API_KEY>" \
  -H "Content-Type: application/json" \
  -d @/tmp/post_payload.json | python3 -m json.tool
```

**4. Parse response:**
- `"status": "published"` on each platform block = success
- `"platformPostUrl"` = direct link to the live post
- `"platformPostId"` = platform-native ID for later reference

### Key Differences from MCP Tools
| Aspect | MCP Tools | Direct API |
|--------|-----------|------------|
| Auth | Automatic (server-side) | User-provided API key |
| Payload format | Inline args | JSON body via file |
| Multi-platform | `posts_cross_post` | `platforms[]` array in JSON |
| Media URLs | Same (public HTTP only) | Same (public HTTP only) |
| Response | Tool output | Raw JSON via curl |

### Pitfall: Shell Escaping with Newlines/Quotes
**NEVER** try to inline JSON with newlines and quotes through bash — it breaks catastrophically. Always write payload to a file first (`write_file` or heredoc), then use `-d @/path/to/file.json`.

### Pitfall: Forgetting to Check for Instagram
The user's Zernio account may only have Facebook + LinkedIn connected. Instagram requires separate OAuth connection. Always check the accounts list response — if Instagram is missing, tell the user explicitly instead of silently skipping.

### Pitfall: Explaining Instead of Acting
When the user says "just do it" after a failure, they want immediate action. Do NOT explain why MCP is down or ask them to wait. Switch to the fallback immediately and report results.

## Multi-API-Key Pattern: Separate Zernio Users for Different Platforms

**Critical discovery:** A single Zernio user/profile may NOT have all social accounts connected. The user may have multiple Zernio accounts (different API keys) each with different platform connections.

### Detection Pattern
When `accounts_list` returns only Facebook + LinkedIn but the user also wants Instagram/Threads:
1. Ask the user: "Do you have a separate Zernio account for Instagram?"
2. If yes, get the SECOND API key
3. Query accounts with the second key — Instagram and Threads will likely appear there

### Why This Happens
- Zernio OAuth connections are scoped per user/profile
- Facebook/LinkedIn may be under one Zernio user (business profile)
- Instagram/Threads may be under a different Zernio user (creator profile)
- Each user has its own API key

### Working with Multiple Keys

**Step 1: Query both keys to discover all accounts**
```bash
# Key 1 — likely has Facebook + LinkedIn
curl -s -H "Authorization: Bearer <KEY_1>" https://api.zernio.com/v1/accounts | python3 -m json.tool

# Key 2 — likely has Instagram + Threads
curl -s -H "Authorization: Bearer <KEY_2>" https://api.zernio.com/v1/accounts | python3 -m json.tool
```

**Step 2: Post to each platform with its corresponding key**
```bash
# Facebook + LinkedIn (Key 1)
curl -s -X POST https://api.zernio.com/v1/posts \
  -H "Authorization: Bearer <KEY_1>" \
  -H "Content-Type: application/json" \
  -d @/tmp/post_payload.json

# Instagram + Threads (Key 2)
curl -s -X POST https://api.zernio.com/v1/posts \
  -H "Authorization: Bearer <KEY_2>" \
  -H "Content-Type: application/json" \
  -d @/tmp/threads_payload.json
```

### Pitfall: Assuming One Key Rules All Platforms
**NEVER** assume a single Zernio API key has access to all the user's social accounts. Always check. If a platform is missing from the accounts list, ask about a second key BEFORE concluding the platform isn't connected.

## Instagram Image Posting: mediaItems Format

Instagram requires the `mediaItems` array format (not `media_urls` string). This is different from Facebook/LinkedIn.

### Correct Instagram Payload
```bash
cat > /tmp/ig_payload.json << 'EOF'
{
  "content": "Your caption here.\n\nWith newlines.",
  "mediaItems": [
    {"type": "image", "url": "https://public-url.com/image.jpg"}
  ],
  "platforms": [
    {"platform": "instagram", "accountId": "<IG_ACCOUNT_ID>"}
  ],
  "publishNow": true
}
EOF
```

### Key Differences
| Platform | Media Field | Format |
|----------|-------------|--------|
| Facebook, LinkedIn | `media_urls` | Comma-separated string of URLs |
| Instagram, Threads | `mediaItems` | Array of `{type, url}` objects |

### Testing Instagram Media Upload
Before posting the user's actual image, do a test post with a placeholder image:
```bash
# Test with a public placeholder image
cat > /tmp/test_ig.json << 'EOF'
{
  "content": "Test post — please ignore",
  "mediaItems": [{"type": "image", "url": "https://picsum.photos/800/800"}],
  "platforms": [{"platform": "instagram", "accountId": "<IG_ID>"}],
  "publishNow": true
}
EOF

curl -s -X POST https://api.zernio.com/v1/posts \
  -H "Authorization: Bearer <KEY>" \
  -H "Content-Type: application/json" \
  -d @/tmp/test_ig.json | python3 -m json.tool
```

If the test returns `"status": "publishing"` with a `pendingContainerId`, the format works. Delete the test post after confirming.

### Temporary Public Image Hosting for Instagram
When you need to post a local image to Instagram but have no persistent hosting:

**Option A: litterbox.catbox.moe (1-hour expiry)**
```bash
# Upload image to temporary public host
curl -s -X POST https://litterbox.catbox.moe/resources/internals/api.php \
  -F "reqtype=fileupload" \
  -F "time=1h" \
  -F "fileToUpload=@/path/to/image.jpg"
# Returns: https://litter.catbox.moe/xxxxx.jpg
```

**Option B: Any public image URL the user already has** (Imgur, S3, CDN, etc.)

**Warning:** Temporary URLs expire. For scheduled posts, use persistent hosting (S3, R2, etc.). For immediate posts, temporary hosting is fine.

## Testing

```bash
# Test MCP connection
hermes mcp test zernio

# List available Zernio tools
hermes mcp list

# Check post status
hermes chat -q "Use mcp_zernio_posts_list status published limit 5"

# Test direct API (fallback)
curl -s -H "Authorization: Bearer <KEY>" https://api.zernio.com/v1/accounts | head -20
```

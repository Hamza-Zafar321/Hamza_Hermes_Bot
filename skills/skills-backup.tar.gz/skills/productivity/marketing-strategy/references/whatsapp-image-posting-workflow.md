# WhatsApp Image Posting Workflow (Zernio)

Reference for posting images with captions to WhatsApp via Zernio's API, including the temporary public image hosting pattern used when no persistent CDN is available.

## Use Case
User sends an image file (e.g., from WhatsApp chat) and wants it posted to Instagram/Facebook/LinkedIn with a caption. The image exists locally but Zernio requires a public HTTP(S) URL.

## The Problem
- Zernio's `mediaItems` (Instagram) and `media_urls` (Facebook/LinkedIn) require **publicly accessible URLs**
- Local file paths (`/home/user/image.jpg`) are rejected
- The user may not have a persistent image hosting solution (S3, CDN, etc.)
- MCP media upload tools may be unavailable (timeouts, failures)

## The Solution: Temporary Public Hosting + Direct API

### Step 1: Save the User's Image
The image arrives as a file in the conversation. Save it to a known path:
```
/home/ubuntu/.hermes/image_cache/img_xxx.jpg
```

### Step 2: Upload to Temporary Public Host
Use litterbox.catbox.moe for 1-hour temporary hosting:
```bash
curl -s -X POST https://litterbox.catbox.moe/resources/internals/api.php \
  -F "reqtype=fileupload" \
  -F "time=1h" \
  -F "fileToUpload=@/home/ubuntu/.hermes/image_cache/img_xxx.jpg"
# Response: https://litter.catbox.moe/xxxxx.jpg
```

**Alternative hosts:**
- `curl -F "file=@image.jpg" https://0x0.st` — returns direct URL
- Any other temporary file host that returns a direct image URL

### Step 3: Create Platform-Specific Payload

**For Instagram (mediaItems format):**
```bash
cat > /tmp/ig_payload.json << 'EOF'
{
  "content": "Your caption here.\n\nWith newlines and 'quotes'.",
  "mediaItems": [
    {"type": "image", "url": "https://litter.catbox.moe/xxxxx.jpg"}
  ],
  "platforms": [
    {"platform": "instagram", "accountId": "<IG_ACCOUNT_ID>"}
  ],
  "publishNow": true
}
EOF
```

**For Facebook/LinkedIn (media_urls format):**
```bash
cat > /tmp/fb_payload.json << 'EOF'
{
  "content": "Your caption here.\n\nWith newlines and 'quotes'.",
  "media_urls": "https://litter.catbox.moe/xxxxx.jpg",
  "platforms": [
    {"platform": "facebook", "accountId": "<FB_ACCOUNT_ID>"}
  ],
  "publishNow": true
}
EOF
```

### Step 4: Post via Direct API
```bash
curl -s -X POST https://api.zernio.com/v1/posts \
  -H "Authorization: Bearer <API_KEY>" \
  -H "Content-Type: application/json" \
  -d @/tmp/ig_payload.json | python3 -m json.tool
```

### Step 5: Verify Response
Look for:
- `"status": "publishing"` or `"published"` in the platform block
- `"platformPostUrl"` = direct link to the live post
- `"pendingContainerId"` (Instagram) = container being processed

## Critical Pitfalls

### Pitfall: Shell Escaping with Quotes and Newlines
**NEVER** inline JSON with single quotes, double quotes, and newlines through bash. It breaks catastrophically. Always write to a file first.

**WRONG:**
```bash
curl -d '{"content": "It\'s working\n\nNew line"}'  # BREAKS
```

**RIGHT:**
```bash
cat > /tmp/payload.json << 'EOF'
{"content": "It's working\n\nNew line"}
EOF
curl -d @/tmp/payload.json
```

### Pitfall: Temporary URL Expires Before Posting
Litterbox URLs expire in 1 hour. If there's a delay between upload and post:
1. The URL may become invalid
2. Instagram/Facebook will fail to fetch the image
3. Post status will show "failed"

**Fix:** Upload and post in the same action sequence. Do not upload, then wait, then post.

### Pitfall: Instagram Uses mediaItems, Others Use media_urls
- Instagram/Threads: `mediaItems: [{"type": "image", "url": "..."}]`
- Facebook/LinkedIn: `media_urls: "https://..."`
- Sending the wrong format = 400 Bad Request

### Pitfall: Forgetting to Test First
Always do a test post with a placeholder image before posting the user's actual content:
```bash
# Quick test
curl -s -X POST https://api.zernio.com/v1/posts \
  -H "Authorization: Bearer <KEY>" \
  -H "Content-Type: application/json" \
  -d '{"content":"test","mediaItems":[{"type":"image","url":"https://picsum.photos/800/800"}],"platforms":[{"platform":"instagram","accountId":"<ID>"}],"publishNow":true}'
```

## Complete Working Example

```bash
# 1. Image already saved at: /home/ubuntu/.hermes/image_cache/img_ad7bbfc62889.jpg

# 2. Upload to temporary host
PUBLIC_URL=$(curl -s -X POST https://litterbox.catbox.moe/resources/internals/api.php \
  -F "reqtype=fileupload" \
  -F "time=1h" \
  -F "fileToUpload=@/home/ubuntu/.hermes/image_cache/img_ad7bbfc62889.jpg")
echo "Public URL: $PUBLIC_URL"

# 3. Create Instagram payload
cat > /tmp/ig_post.json << 'EOF'
{
  "content": "Your competition isn't hiring more people. They're deploying AI agents that work 24/7, never call in sick, and scale infinitely.\n\nWhile you're debating, they're automating.\n\nThe gap isn't closing. It's widening.\n\nDM me 'AUTOMATE' if you're ready to stop watching and start building.",
  "mediaItems": [{"type": "image", "url": "PUBLIC_URL_PLACEHOLDER"}],
  "platforms": [{"platform": "instagram", "accountId": "6a243e002b2567671afd048c"}],
  "publishNow": true
}
EOF
sed -i "s|PUBLIC_URL_PLACEHOLDER|$PUBLIC_URL|g" /tmp/ig_post.json

# 4. Post
curl -s -X POST https://api.zernio.com/v1/posts \
  -H "Authorization: Bearer sk_xxxxxxxxxxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d @/tmp/ig_post.json | python3 -m json.tool
```

## When User Says "Post This Image"

1. **Acknowledge immediately** — "Got it, posting your image to [platform] now."
2. **Upload to temporary host** — litterbox.catbox.moe (1h expiry)
3. **Create payload file** — platform-specific format (mediaItems vs media_urls)
4. **Post via direct API** — use the correct API key for the target platform
5. **Report result** — share the post URL or status

Do NOT explain why you need a public URL. Do NOT ask the user to upload it somewhere. Just do it.

# Axovion.io — User Business Profile

## Founder
- **Name:** Muhammad Hamza Zafar
- **Age:** 20
- **Location:** Lahore, Pakistan
- **Education:** Associate degree in Computer Science (CS) — froze 3rd semester due to financial issues
- **Current Job:** Call center agent (3 years), handling spray foam insulation leads for UK market
- **Marketing Experience:** Complete beginner — self-describes as knowing "nothing at all"

## Business Overview
- **Name:** Axovion.io
- **Industry:** AI Automation Agency
- **Services:**
  1. Chatbots (primary)
  2. AI automation agents (primary)
  3. Content generation (only if client specifically requests)
- **Current Target Market:** E-commerce businesses
- **Future Flexibility:** May expand niche in foreseeable future
- **Founder's Role:** Marketing

## Technical Context
- **Developer:** Main developer uses Hermes agent for development
- **Repository:** https://github.com/joking-really/axovion-full-project
- **Tech Stack:** React + Node.js + MongoDB + Vercel
- **Status:** MVP code exists, post-MVP pages/features planned

## Communication Preferences
- **Platform:** WhatsApp (no markdown rendering — use plain text only)
- **Learning Style:** Prefers sequential, one-by-one questioning for discovery
- **Jargon Tolerance:** Keep it simple and beginner-friendly
- **Frustration Signal:** Gets frustrated when agent cannot perform expected actions (e.g., GitHub access). If something isn't working, explain why clearly and offer concrete alternatives immediately.
- **Expectation Management:** User may believe technical setup is complete when it is not (e.g., GitHub tokens). Always verify before assuming access works.

## Marketing Journey Status
- Just beginning to learn marketing fundamentals
- Interested in step-by-step, beginner-friendly guidance
- 18 hours/week available for marketing activities
- Zero marketing budget — organic-only strategy
- Planning to use all social media platforms (Facebook, Instagram, YouTube, Reddit, LinkedIn, Twitter)
- Will use AI tools for content creation
- Wants a `context.txt` file in GitHub repo for session continuity

## Content Generation Workflow (Established)
- **Tool stack**: ChatGPT/Gemini for prompt generation → manual creation in Pomelli
- **Batch schedule**: Sunday, 2-3 hours, 7 posts per week
- **Post time**: 6-9 PM daily
- **Templates**: 4 reusable (Pain Point + Chat Mockup, Curiosity + Abstract, Branded Promo, Educational Tip)
- **Visual style**: Dark #0A0A0F + neon green #00FF41, 4:5 portrait, mixed fonts
- **CTA**: "DM me 'AUTOMATE'" on every post
- **Logo**: Only on every 3rd/4th post (Branded Promo template)
- **Tone mix**: 50% pain point agitation / 50% curiosity gap
- **AI prompt detail level**: Full visual specification (hex codes, element positions, font sizes, effects)
- See `references/social-media-image-prompts.md` for complete system documentation

## Notes for Future Sessions
- Keep explanations simple and jargon-free
- Use concrete examples related to e-commerce and chatbots
- Focus on actionable steps over theory
- Acknowledge his call center background as relevant (sales experience, understanding customer pain points)
- When discussing GitHub repos, verify access tokens are actually configured — user may believe access is granted when it is not
- **Mandatory Workflow — 10 Question Protocol:** For EVERY task, the user requires:
  1. Exactly 10 questions per task
  2. One question at a time (never dump multiple)
  3. 3-4 options (A, B, C, D) for every question
  4. Highlighted recommendation for each question
  5. Wait for answer before next question
  6. Acknowledge choice briefly before continuing
  7. Track question number ("Question X of 10")
  8. Restart numbering if user corrects understanding mid-flow
  9. Synthesize answers after all 10 questions
  10. Stop immediately if user says "actually" or corrects an assumption — acknowledge and restart from relevant question
- **Extended Discovery Allowed:** User may request more than 10 questions for deep-dive topics (e.g., 50 questions for content generation system design). Adapt the protocol length to their request while keeping the one-by-one format.

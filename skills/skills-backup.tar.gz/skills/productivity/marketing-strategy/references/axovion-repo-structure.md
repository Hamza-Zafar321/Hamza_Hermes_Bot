# Axovion.io Repository Structure

**Source:** https://github.com/joking-really/axovion-full-project

## Overview
Complete project repository for Axovion.io AI automation agency. Contains MVP code, build instructions, and post-MVP roadmap.

## Repository Contents

### MVP Code (`mvp-code/`)
- `client/` — React frontend
- `server/` — Node.js backend
- Complete build instructions in `MVP.md`

### Page Instructions (`PAGE-*.md`)
| File | Route | Description |
|------|-------|-------------|
| PAGE-Blog.md | `/blog` | Blog / Resources page |
| PAGE-Services.md | `/services` | Services detail page with 8 service cards |
| PAGE-About.md | `/about` | About page |
| PAGE-CaseStudies.md | `/case-studies` | Results / Portfolio page |
| PAGE-Team.md | `/team` | Team page (founder face post-MVP) |

### Feature Instructions (`FEATURE-*.md`)
| File | Description |
|------|-------------|
| FEATURE-SEO-Optimization.md | SEO strategy |
| FEATURE-Calling-Agent.md | AI calling agent (Vapi/Retell) |
| FEATURE-Advanced-Dashboard.md | Admin dashboard enhancements |
| FEATURE-Audit-Automation.md | Instant AI audit report generation |
| FEATURE-Email-Automation.md | Email sequences (Resend/SendGrid) |

### Social Media Assets (`social-media/`)
- `axovion_linkedin_banner.png`
- `axovion_linkedin_pollinations.png`
- `automation_ideas_complete.json`
- `automation_ideas_import.csv`
- `axovion_fixed_workflow.json`

### Other Files
- `README.md` — Quick start and deployment guide
- `PROJECT-CONTEXT.md` — Full project summary, env vars, decisions
- `.gitignore` — Standard Node.js ignore patterns

## Environment Variables (from PROJECT-CONTEXT.md)
```
MONGODB_URI=
PORT=5000
KIMI_API_KEY=           # or GROQ_API_KEY
NEXTAUTH_SECRET=
NEXTAUTH_URL=
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
ADMIN_EMAIL=
```

## Key Decisions
- No instant AI report in MVP — manual follow-up for first clients
- Brand-first, no founder face yet — team page comes post-MVP
- Dark luxury + AI-native design — black, silver, cyan, orange
- 6 signature animations max — performance over quantity
- English-speaking markets only

## Deployment Plan
1. Frontend: Vercel (from GitHub)
2. Backend: Railway/Render/Vercel Serverless
3. Database: MongoDB Atlas
4. Domain: axovion.io

## Services Listed
1. Free AI Audit
2. Customer Support Chatbots (Website, WhatsApp)
3. Lead Generation & Follow-Up
4. Booking Automation
5. E-Commerce Support
6. Abandoned Cart Recovery
7. CRM & Email Automation
8. AI Consulting & Strategy

## Important Notes
- MVP chatbot uses static responses (no live API)
- Admin dashboard has mock data (connect to real API for production)
- Placeholder testimonials — replace with real ones
- Calendly link needs to be added to Contact page
- Kimi K2.6 API integration needed for chatbot and audit automation

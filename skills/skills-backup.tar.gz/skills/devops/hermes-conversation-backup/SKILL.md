---
name: hermes-conversation-backup
description: "Export Hermes conversation sessions to Markdown and push to GitHub for durable backup."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, backup, github, sessions, cron]
    related_skills: [hermes-agent, github-repo-management]
---

# Hermes Conversation Backup

Export all Hermes conversation sessions from SQLite to Markdown files and push to a GitHub repository. Supports one-time export and automated cron scheduling.

## When to Use

- User wants conversation history backed up to GitHub
- User wants automated periodic backups (e.g., every 48 hours)
- Migrating sessions between environments
- Creating a searchable archive of past work

## Prerequisites

- GitHub Personal Access Token with `repo` scope
- Target repository (can be empty)
- Hermes session database at `~/.hermes/state.db`

## Quick Start

### One-Time Export

```python
import sqlite3
import os
import urllib.request
import json
import base64
from datetime import datetime

DB_PATH = os.path.expanduser("~/.hermes/state.db")
TOKEN = "github_pat_..."
REPO = "username/repo-name"

def export_sessions():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, title, started_at, source, message_count, model FROM sessions ORDER BY started_at DESC")
    sessions = cursor.fetchall()
    
    export_dir = "/tmp/hermes_backup"
    os.makedirs(export_dir, exist_ok=True)
    
    for session in sessions:
        session_id, title, started_at, source, msg_count, model = session
        
        if isinstance(started_at, (int, float)):
            dt = datetime.fromtimestamp(started_at)
            date_str = dt.strftime('%Y-%m-%d')
        elif isinstance(started_at, str):
            date_str = started_at[:10] if len(started_at) >= 10 else 'unknown'
        else:
            date_str = 'unknown'
        
        cursor.execute("SELECT role, content, timestamp, tool_name FROM messages WHERE session_id = ? ORDER BY timestamp ASC", (session_id,))
        messages = cursor.fetchall()
        
        safe_title = title.replace('/', '-').replace('\\', '-').replace(' ', '-') if title else 'untitled'
        filename = f"{date_str}-{safe_title}.md"
        
        md_content = f"""# Session: {title or 'Untitled'}\n\n- **Date:** {started_at}\n- **Source:** {source}\n- **Model:** {model}\n- **Messages:** {msg_count}\n- **Session ID:** {session_id}\n\n---\n\n"""
        for msg in messages:
            role, content, timestamp, tool_name = msg
            if not content:
                continue
            if role == 'user':
                md_content += f"## User\n\n{content}\n\n---\n\n"
            elif role == 'assistant':
                md_content += f"## Assistant\n\n{content}\n\n---\n\n"
            elif role == 'tool':
                md_content += f"## Tool: {tool_name or 'unknown'}\n\n```\n{content[:500]}\n```\n\n---\n\n"
        
        filepath = os.path.join(export_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(md_content)
    
    return export_dir, sessions
```

### Push to GitHub

```python
def upload_to_github(export_dir, sessions, token, repo):
    import re
    
    for session in sessions:
        session_id, title, started_at, source, msg_count, model = session
        
        if isinstance(started_at, (int, float)):
            dt = datetime.fromtimestamp(started_at)
            date_str = dt.strftime('%Y-%m-%d')
        elif isinstance(started_at, str):
            date_str = started_at[:10] if len(started_at) >= 10 else 'unknown'
        else:
            date_str = 'unknown'
        
        safe_title = title.replace('/', '-').replace('\\', '-').replace(' ', '-') if title else 'untitled'
        filename = f"{date_str}-{safe_title}.md"
        filepath = os.path.join(export_dir, filename)
        
        if not os.path.exists(filepath):
            continue
        
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Redact secrets before upload
        content = re.sub(r'sk_[a-zA-Z0-9]{20,}', '[REDACTED_API_KEY]', content)
        content = re.sub(r'github_pat_[a-zA-Z0-9]{20,}', '[REDACTED_GITHUB_TOKEN]', content)
        content = re.sub(r'ghp_[a-zA-Z0-9]{20,}', '[REDACTED_GITHUB_PAT]', content)
        
        encoded = base64.b64encode(content.encode('utf-8')).decode()
        
        data = json.dumps({
            "message": f"Auto-backup: {filename}",
            "content": encoded
        }).encode()
        
        req = urllib.request.Request(
            f"https://api.github.com/repos/{repo}/contents/{filename}",
            data=data,
            headers={
                "Authorization": f"token {token}",
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "Hermes-Agent",
                "Content-Type": "application/json"
            },
            method="PUT"
        )
        
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                print(f"✓ {filename}")
        except urllib.error.HTTPError as e:
            if e.code == 422:
                # File exists, update it
                req2 = urllib.request.Request(
                    f"https://api.github.com/repos/{repo}/contents/{filename}",
                    headers={"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json", "User-Agent": "Hermes-Agent"}
                )
                with urllib.request.urlopen(req2, timeout=15) as resp2:
                    data2 = json.loads(resp2.read().decode())
                    sha = data2['sha']
                
                update_data = json.dumps({
                    "message": f"Auto-backup update: {filename}",
                    "content": encoded,
                    "sha": sha
                }).encode()
                
                req3 = urllib.request.Request(
                    f"https://api.github.com/repos/{repo}/contents/{filename}",
                    data=update_data,
                    headers={
                        "Authorization": f"token {token}",
                        "Accept": "application/vnd.github.v3+json",
                        "User-Agent": "Hermes-Agent",
                        "Content-Type": "application/json"
                    },
                    method="PUT"
                )
                with urllib.request.urlopen(req3, timeout=30) as resp3:
                    print(f"✓ Updated: {filename}")
            else:
                print(f"✗ {filename}: {e.code}")
        except Exception as e:
            print(f"✗ {filename}: {e}")
```

## Automated Cron Backup

Create a Python script at `~/.hermes/scripts/backup_conversations.py` combining the above, then schedule:

```bash
hermes cron create "0 */48 * * *" --name "conversation-backup" --script backup_conversations.py --no-agent
```

Or via the `cronjob` tool:
```json
{
  "action": "create",
  "name": "conversation-backup",
  "schedule": "0 */48 * * *",
  "script": "backup_conversations.py",
  "no_agent": true
}
```

## Secret Redaction

Always redact before uploading to GitHub. GitHub's secret scanning will block commits containing:
- GitHub PATs (`github_pat_...`, `ghp_...`)
- API keys (`sk_...`)
- Generic high-entropy tokens

Use regex substitution:
```python
import re
content = re.sub(r'sk_[a-zA-Z0-9]{20,}', '[REDACTED_API_KEY]', content)
content = re.sub(r'github_pat_[a-zA-Z0-9]{20,}', '[REDACTED_GITHUB_TOKEN]', content)
```

## File Naming Convention

Use `YYYY-MM-DD-session-title.md` for chronological sorting. Sanitize titles:
```python
safe_title = title.replace('/', '-').replace('\\', '-').replace(' ', '-') if title else 'untitled'
filename = f"{date_str}-{safe_title}.md"
```

## Pitfalls

- **Repo 409 errors** — File already exists. Get SHA via API and update instead of create.
- **Repo 404 errors** — Wrong repo path. Verify `owner/repo` format.
- **Empty repo** — First file must be created via API; subsequent files work normally.
- **Large sessions** — Messages with huge tool output may exceed GitHub's file size limit. Truncate tool output to ~500 chars.
- **Token scope** — PAT needs `repo` scope for private repos, `public_repo` for public repos.

## Database Schema Reference

```sql
-- Sessions table
CREATE TABLE sessions (
    id TEXT PRIMARY KEY,
    title TEXT,
    started_at REAL,
    source TEXT,
    message_count INTEGER,
    model TEXT
);

-- Messages table
CREATE TABLE messages (
    id INTEGER PRIMARY KEY,
    session_id TEXT,
    role TEXT,  -- 'user', 'assistant', 'tool'
    content TEXT,
    timestamp REAL,
    tool_name TEXT
);
```

See `scripts/backup_conversations.py` for a complete, runnable backup script.

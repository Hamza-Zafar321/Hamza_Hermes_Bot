#!/usr/bin/env python3
"""
Hermes Conversation Backup Script
Exports all sessions from ~/.hermes/state.db to Markdown and pushes to GitHub.

Usage:
    python3 backup_conversations.py

Environment:
    GITHUB_TOKEN - GitHub Personal Access Token with repo scope
    GITHUB_REPO  - Target repo in "owner/name" format
"""

import sqlite3
import os
import urllib.request
import json
import base64
import re
from datetime import datetime

DB_PATH = os.path.expanduser("~/.hermes/state.db")
TOKEN = os.getenv("GITHUB_TOKEN", "")
REPO = os.getenv("GITHUB_REPO", "")


def export_sessions():
    """Export all sessions to Markdown files in /tmp/hermes_backup."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        "SELECT id, title, started_at, source, message_count, model "
        "FROM sessions ORDER BY started_at DESC"
    )
    sessions = cursor.fetchall()

    export_dir = "/tmp/hermes_backup"
    os.makedirs(export_dir, exist_ok=True)

    for session in sessions:
        session_id, title, started_at, source, msg_count, model = session

        if isinstance(started_at, (int, float)):
            dt = datetime.fromtimestamp(started_at)
            date_str = dt.strftime('%Y-%m-%d')
        elif isinstance(started_at, str):
            date_str = started_at[:10] if len(started_at) >= 10 else 'unknown'
        else:
            date_str = 'unknown'

        cursor.execute(
            "SELECT role, content, timestamp, tool_name "
            "FROM messages WHERE session_id = ? ORDER BY timestamp ASC",
            (session_id,)
        )
        messages = cursor.fetchall()

        safe_title = (
            title.replace('/', '-').replace('\\', '-').replace(' ', '-')
            if title else 'untitled'
        )
        filename = f"{date_str}-{safe_title}.md"

        md_content = f"""# Session: {title or 'Untitled'}

- **Date:** {started_at}
- **Source:** {source}
- **Model:** {model}
- **Messages:** {msg_count}
- **Session ID:** {session_id}

---

"""
        for msg in messages:
            role, content, timestamp, tool_name = msg
            if not content:
                continue
            if role == 'user':
                md_content += f"## User\n\n{content}\n\n---\n\n"
            elif role == 'assistant':
                md_content += f"## Assistant\n\n{content}\n\n---\n\n"
            elif role == 'tool':
                md_content += (
                    f"## Tool: {tool_name or 'unknown'}\n\n"
                    f"```\n{content[:500]}\n```\n\n---\n\n"
                )

        filepath = os.path.join(export_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(md_content)

    return export_dir, sessions


def redact_secrets(content: str) -> str:
    """Remove sensitive tokens before uploading to GitHub."""
    content = re.sub(r'sk_[a-zA-Z0-9]{20,}', '[REDACTED_API_KEY]', content)
    content = re.sub(r'github_pat_[a-zA-Z0-9]{20,}', '[REDACTED_GITHUB_TOKEN]', content)
    content = re.sub(r'ghp_[a-zA-Z0-9]{20,}', '[REDACTED_GITHUB_PAT]', content)
    return content


def upload_to_github(export_dir, sessions):
    """Push exported Markdown files to GitHub repository."""
    for session in sessions:
        session_id, title, started_at, source, msg_count, model = session

        if isinstance(started_at, (int, float)):
            dt = datetime.fromtimestamp(started_at)
            date_str = dt.strftime('%Y-%m-%d')
        elif isinstance(started_at, str):
            date_str = started_at[:10] if len(started_at) >= 10 else 'unknown'
        else:
            date_str = 'unknown'

        safe_title = (
            title.replace('/', '-').replace('\\', '-').replace(' ', '-')
            if title else 'untitled'
        )
        filename = f"{date_str}-{safe_title}.md"
        filepath = os.path.join(export_dir, filename)

        if not os.path.exists(filepath):
            continue

        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        content = redact_secrets(content)
        encoded = base64.b64encode(content.encode('utf-8')).decode()

        data = json.dumps({
            "message": f"Auto-backup: {filename}",
            "content": encoded
        }).encode()

        req = urllib.request.Request(
            f"https://api.github.com/repos/{REPO}/contents/{filename}",
            data=data,
            headers={
                "Authorization": f"token {TOKEN}",
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "Hermes-Agent",
                "Content-Type": "application/json"
            },
            method="PUT"
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                print(f"✓ {filename}")
        except urllib.error.HTTPError as e:
            if e.code == 422:
                # File exists — get SHA and update
                try:
                    req2 = urllib.request.Request(
                        f"https://api.github.com/repos/{REPO}/contents/{filename}",
                        headers={
                            "Authorization": f"token {TOKEN}",
                            "Accept": "application/vnd.github.v3+json",
                            "User-Agent": "Hermes-Agent"
                        }
                    )
                    with urllib.request.urlopen(req2, timeout=15) as resp2:
                        data2 = json.loads(resp2.read().decode())
                        sha = data2['sha']

                    update_data = json.dumps({
                        "message": f"Auto-backup update: {filename}",
                        "content": encoded,
                        "sha": sha
                    }).encode()

                    req3 = urllib.request.Request(
                        f"https://api.github.com/repos/{REPO}/contents/{filename}",
                        data=update_data,
                        headers={
                            "Authorization": f"token {TOKEN}",
                            "Accept": "application/vnd.github.v3+json",
                            "User-Agent": "Hermes-Agent",
                            "Content-Type": "application/json"
                        },
                        method="PUT"
                    )
                    with urllib.request.urlopen(req3, timeout=30) as resp3:
                        print(f"✓ Updated: {filename}")
                except Exception as e2:
                    print(f"✗ Update failed: {filename} - {e2}")
            else:
                print(f"✗ {filename}: {e.code}")
        except Exception as e:
            print(f"✗ {filename}: {e}")


if __name__ == "__main__":
    if not TOKEN or not REPO:
        print("Error: Set GITHUB_TOKEN and GITHUB_REPO environment variables")
        exit(1)

    print(f"Starting backup at {datetime.now().isoformat()}")
    export_dir, sessions = export_sessions()
    upload_to_github(export_dir, sessions)
    print(f"Backup complete at {datetime.now().isoformat()}")

# Zernio MCP Server Reference

Quick reference for the Zernio social media MCP server at `https://mcp.zernio.com/mcp`.

## Setup

Use the `mcp-remote` stdio bridge (more reliable than native HTTP):

```yaml
mcp_servers:
  zernio:
    command: "npx"
    args:
      - "-y"
      - "mcp-remote@latest"
      - "https://mcp.zernio.com/mcp"
      - "--header"
      - "Authorization: Bearer YOUR_API_KEY"
    timeout: 180
    connect_timeout: 60
```

Install bridge: `npm install -g mcp-remote@latest`

## Key Tools

| Tool | Purpose |
|------|---------|
| `mcp_zernio_accounts_list` | Show connected social accounts |
| `mcp_zernio_posts_publish_now` | Publish immediately |
| `mcp_zernio_posts_create` | Create draft/scheduled post |
| `mcp_zernio_posts_cross_post` | Post to multiple platforms |
| `mcp_zernio_media_generate_upload_link` | Get browser upload URL |
| `mcp_zernio_media_check_upload_status` | Check upload completion |

## Media Upload Flow

AI clients cannot access local files. The flow is:

1. Call `mcp_zernio_media_generate_upload_link` → get upload URL
2. User opens URL in browser and uploads file
3. Call `mcp_zernio_media_check_upload_status` with token
4. Use returned public URL in `posts_create` or `posts_publish_now`

**Workaround for automation:** Host image on a temporary public URL (localtunnel, ngrok) and pass that URL directly to `media_urls` parameter.

## Platform IDs

Platforms are referenced by lowercase name: `twitter`, `instagram`, `linkedin`, `tiktok`, `bluesky`, `facebook`, `youtube`, `pinterest`, `threads`, `googlebusiness`, `telegram`, `snapchat`

## Multi-Account Handling

When user has multiple accounts on same platform, `account_id` is required. Call `accounts_list` first to discover IDs. Otherwise Zernio returns an error with candidate account IDs.

## Common Errors

- **"exact content was already posted"** — Zernio deduplicates within 24h. Tweak copy slightly and retry.
- **"No accounts connected"** — User needs to connect accounts at zernio.com first.
- **Upload link 404** — Link expired or token invalid. Generate a new one.

# Session Continuity Pattern for GitHub Repositories

## Problem
When a user creates a new Hermes session (server restart, new conversation), all context is lost. The user wants future Hermes instances to quickly understand the project by cloning a GitHub repository.

## Solution: context.txt File

Create a `context.txt` file in the repository root that contains:
1. Project overview and key decisions
2. User profile and preferences
3. Conversation history summary
4. Current status and next steps
5. Update instructions

### Template Structure

```
# [Project Name] - Hermes Agent Context File
# Last Updated: [DATE]
# Purpose: Continuity file for Hermes agent sessions

================================================================================
PROJECT OVERVIEW
================================================================================
[Key business/project details]

================================================================================
USER PROFILE
================================================================================
[Name, role, experience level, preferences]

================================================================================
CONVERSATION HISTORY SUMMARY
================================================================================
[Key questions asked and answers given]

================================================================================
IMPORTANT NOTES FOR FUTURE HERMES
================================================================================
[Communication preferences, pitfalls, known issues]

================================================================================
NEXT STEPS / TODO
================================================================================
[Current priorities and action items]

================================================================================
UPDATE INSTRUCTIONS
================================================================================
[How and when to update this file]
```

## Implementation

1. Create `context.txt` locally in the repository
2. Commit and push to GitHub
3. Update after significant milestones or decisions
4. At minimum, update once per day during active development

## Security Warning

- NEVER include API keys, tokens, or passwords in context.txt
- NEVER push .env files to GitHub
- Use `.env.example` for environment variable templates

## Example Usage

When a new Hermes session starts:
1. User provides GitHub repo URL
2. Hermes clones the repository
3. Hermes reads `context.txt` to understand context
4. Conversation continues seamlessly

## This Session's Example

Repository: https://github.com/joking-really/axovion-full-project
Created: `/home/ubuntu/axovion-full-project/context.txt`
Status: Committed locally, needs push to GitHub (token permission issue pending)

---
name: z-image-turbo-prompting
description: Z-Image Turbo prompt engineering guide for Axovion.io image/carousel generation
version: 1.0
---

# Z-Image Turbo Prompting Guide for Axovion

## Model Basics
- 6B parameter S3-DiT (Scalable Single-Stream Diffusion Transformer)
- NO negative prompts (guidance_scale=0.0, ignored)
- Sentence-based prompts, NOT comma-separated tag soup
- Attention cap ~512 tokens (expandable to 1024)
- Subject + any text to render MUST be at start of prompt

## Axovion Brand Rules
- Dark background + neon BLUE accent (not green)
- Bold high-contrast meme-style social media posts
- 4:5 portrait ratio for carousels
- Mixed fonts: big bold headline + clean body
- Human faces + human beings + robot/AI element in EVERY image
- Realistic/cinematic look — avoid plastic beauty-stock
- Text on images: exactly 6-7 words max per image
- No more than 6-7 words, no less than 5

## The 6-Part Prompt Formula
```
[Subject] + [Scene] + [Composition] + [Lighting] + [Style] + [Constraints]
```

## Photography Vocabulary (Use These)

### For Candid Realism
- "Shot on a point-and-shoot film camera"
- "Handheld iPhone snapshot with slight motion blur"
- "Disposable camera aesthetic, slight overexposure"

### For Cinematic
- "Shot on Fujifilm GFX100 II medium format camera, 110mm f/2 lens"
- "Anamorphic lens flare, 2.39:1 crop, teal-and-orange grade"
- "Canon R5, 35mm prime, natural window light"

### For Film Stock
- "Kodak Portra 400 tones, warm skin rendition"
- "Cinestill 800T, tungsten halation glow"
- "Ilford HP5 black-and-white, heavy silver grain"

### For Ordinary Human Realism
- "Ordinary everyday appearance, not a model"
- "Slightly asymmetrical features"
- "Visible pores and fine skin texture"
- "Unstaged, candid, documentary realism"

## Style Presets

| Style | Prefix | Suffix |
|-------|--------|--------|
| Cinematic Photo | `cinematic photograph, natural lighting` | `high contrast, professional photo, sharp focus, shallow depth of field` |
| Analog Film | `analog film photograph, grainy texture, warm tonal shifts, slight vignette` | `vintage film stock, gentle grain, faded highlights, muted shadows` |
| Cyberpunk | `neon-drenched cyberpunk future, dense holograms` | `glowing circuitry, reflective surfaces, electric atmosphere` |
| Epic Concept Art | `cinematic AAA concept art, sweeping vistas` | `heroic composition, atmospheric depth, ultra-polished rendering` |

## Parameters
- Steps: 8-12 (start at 8)
- Resolution: 1024x1024 native
- Guidance Scale: 0.0
- Fix seed while iterating; randomize for variety

## Constraints (Positive-Only, No Negatives)
- "Correct human anatomy, natural hands and fingers"
- "Sharp focus on subject, no motion blur"
- "No text except specified, no watermark, no logos"
- "Safe for work, non-sexual, no nudity"

## Text on Images Rules
- Put exact text in double quotes
- Describe placement separately
- 6-7 words MAX per image
- Keep text chunky and bold

## API Endpoint (Axovion Hosted)

**URL:** `https://jokinig-really--zimage-api-fastapi-app.modal.run/generate`

**Method:** POST
**Headers:** `Content-Type: application/json`
**Body:** `{"prompt": "your prompt here"}`

**Important:** This is a Modal-hosted app. It **cold-starts after inactivity** (30-60s spin-up). First request after idle period will hang until the container wakes. Plan for this — either pre-warm it or retry with patience.

**Pitfall:** Do NOT use `image_generate` tool for this — that tool targets FAL/OpenAI/xAI backends. Always call the Modal endpoint directly via `curl` or `requests`.

**Example:**
```bash
curl -s -X POST "https://jokinig-really--zimage-api-fastapi-app.modal.run/generate" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"dark background neon blue accents. bold white text: YOUR STORE RUNS YOU"}' \
  -o output.json
```

## Axovion Carousel Templates

### Template 1: Pain Point + Human + Robot
Subject: Stressed human worker + AI robot helper
Scene: Modern office/call center
Text: 6-7 word bold statement
Style: Cinematic photo, dark bg, neon blue accent

### Template 2: Curiosity + Abstract + Human
Subject: Human looking at holographic AI interface
Scene: Futuristic workspace
Text: 6-7 word provocative question
Style: Cyberpunk cinematic

### Template 3: Branded Promo
Subject: Human shaking hands with humanoid robot
Scene: Dark studio with blue neon
Text: "DM me AUTOMATE" or similar CTA
Style: High-contrast cinematic

### Template 4: Educational Tip
Subject: Human + robot side by side working
Scene: Clean modern desk
Text: 6-7 word tip/fact
Style: Professional cinematic

### Template 5: E-commerce Pain Point
Subject: Stressed e-commerce owner drowning in shipping boxes + clean AI dashboard
Scene: Split-screen chaos vs automation
Text: 6-7 word bold statement (e.g., "YOUR STORE RUNS YOU")
Style: Cinematic photo, dark bg, neon blue accent, meme-style
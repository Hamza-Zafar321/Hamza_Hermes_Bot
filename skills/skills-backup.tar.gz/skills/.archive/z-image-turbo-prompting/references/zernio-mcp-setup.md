# Zernio MCP Setup + Image Upload Workarounds

## Context
Session: 2026-06-04. Setting up Zernio MCP for Axovion social media automation.

## MCP Server Config (Hermes)

Zernio runs as a **hosted HTTP MCP server** at `https://mcp.zernio.com/mcp`.
Hermes native MCP client does NOT support remote HTTP directly — must use `mcp-remote` stdio bridge.

### Working Config (`~/.hermes/config.yaml`)
```yaml
mcp_servers:
  zernio:
    command: "npx"
    args:
      - "-y"
      - "mcp-remote@latest"
      - "https://mcp.zernio.com/mcp"
      - "--header"
      - "Authorization: Bearer YOUR_API_KEY_HERE"
    timeout: 180
    connect_timeout: 60
```

### Pitfall: HTTP Transport Fails
This config does NOT work for hosted Zernio:
```yaml
# WRONG — Hermes native HTTP support is limited
mcp_servers:
  zernio:
    url: "https://mcp.zernio.com/mcp"
    headers:
      Authorization: "Bearer ..."
```

### Install mcp-remote
```bash
npm install -g mcp-remote@latest
```

### Verify
```bash
hermes mcp test zernio
hermes mcp list
```

## Image Upload for Zernio Posts

Zernio's `posts_publish_now` and `posts_create` require **publicly accessible URLs** for media. Local file paths are rejected.

### Problem
- User sends image via WhatsApp → saved to `/home/ubuntu/.hermes/image_cache/`
- Zernio cannot read local paths
- Zernio's `media_generate_upload_link` gives a browser upload page, not a programmatic endpoint

### Workaround: Local HTTP Server + Tunnel

When you need to post an image that's only available locally:

1. **Copy image to a temp directory:**
```bash
mkdir -p /tmp/zernio_upload
cp /home/ubuntu/.hermes/image_cache/img_xxx.jpg /tmp/zernio_upload/post.jpg
```

2. **Start a local HTTP server:**
```bash
python3 -m http.server 8765 --directory /tmp/zernio_upload
```

3. **Expose via tunnel (localtunnel):**
```bash
npm install -g localtunnel
lt --port 8765
# Output: https://warm-colts-go.loca.lt
```

4. **Verify the image is accessible:**
```bash
curl -sI https://YOUR-URL/post.jpg
```

5. **Use the public URL in Zernio:**
```
mcp_zernio_posts_publish_now
  platform: linkedin
  account_id: YOUR_ACCOUNT_ID
  content: "Your caption here"
  media_urls: "https://warm-colts-go.loca.lt/post.jpg"
```

### Alternative: Use an existing public image URL
If the image is already hosted somewhere (CDN, S3, etc.), use that URL directly.

## Connected Accounts (Axovion)
- **LinkedIn:** Axovion io (ID: `6a21b7252b2567671acf13cf`)
- **Facebook:** Axovion.io (ID: `6a21b6ff2b2567671acf129a`)

## Duplicate Content Protection
Zernio blocks identical content posted to the same account within 24 hours.
Error: "this exact content was already scheduled, published, or posted"
Fix: Slightly modify the text (change a word, hashtag, or punctuation) before retrying.
